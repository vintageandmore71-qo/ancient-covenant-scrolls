# Load Tasks v5 Build Plan Addendum
## Onsite Agent Lab, Builder Studio, Creative Provider Center, Notes, and Admin Automation

Prepared as an addition to the Load Studio PWA Cinema Experience manual. This addendum defines the v5 build target for Load Tasks as a hosted PWA that can test, inspect, edit, repair, rebuild, and export PWA packages from inside the site.

## Executive decision
Load Tasks v5 should not be described as a standalone file-only app. It is a regular hosted PWA, currently on GitHub Pages and later suitable for private hosting such as Cloudflare Pages Direct Upload. It should remain installable to Home Screen, but its primary role is a browser-based control, testing, repair, and build environment.

## No false positives rule
No build, feature, provider, repair, MoviePWA, AI image, animation, audio, video, or screening result can be marked complete unless Load Tasks has evidence. Evidence means a passing file check, working browser result, downloaded ZIP, valid object URL, returned file, returned blob, playable clip, returned provider response, or live QA confirmation. Patched items remain Patched, Needs QA until live testing passes.

## Build inclusion summary
1. **Existing v4.3 preservation.** Preserve Dashboard, Intake, Validator, Repair Command Center, Help Center, Load AI Helper, Focus Mode, Project Vault, Stable Build Vault, Launch Certificate, Developer Handoff, GitHub Export, dyslexia settings, repair exports, fixed ZIP exports, rollback exports.
2. **Onsite Agent Lab.** Test any PWA, site, HTML package, media-heavy site, admin dashboard, creator page, MoviePWA, or future web app while Load Tasks is open.
3. **PWA Builder Studio.** Upload, dismantle, inspect, edit, rebuild, and export PWA ZIP packages inside the browser.
4. **Media-rich PWA support.** Inspect and repair images, video, audio, animation clips, subtitles, music, sound effects, icons, splash images, and posters.
5. **MoviePWA and CinePWA Studio.** Validate and create movie-style PWAs with poster front screen and premium bottom buttons: Play, Resume, Rate.
6. **Non-developer auto-fix tools.** Provide safe repair buttons, repair previews, clear confidence labels, and fixed ZIP exports.
7. **Onsite creative tools.** Include VN-style editing, AI image workflow, animation workflow, voice/audio tools, scene repair, asset repair, and package rebuild tools.
8. **Provider Center.** Plug in no-key/local-first providers, key-required providers, fallback order, provider health checks, test buttons, and proof rules.
9. **Admin Operations Center.** Automated daily and weekly site health checks, registration checks, email validation checks, security checks, provider health, and repair priority reports.
10. **Screening Center.** Profanity, unsafe text, content labels, child-safe warnings, media review flags, nudity review status, and human review workflows.
11. **Alert Dashboard.** Color-coded and text-labeled alerts: Green Passed, Yellow Needs Review, Orange Warning, Red Broken or Unsafe, Gray Not Tested, Blue Info.
12. **Floating Notes.** Apple Notes-style pop-up notes available on every page, with colors, tags, copy/paste, image attachments, section context, and exports.
13. **How-To System.** Every tool gets dyslexia-friendly step-by-step instructions and a simple Show Steps button.
14. **Premium design system.** Modern dark interface, gold/yellow glow, sleek SVG icons, large tap targets, clean typography, and no emojis in the UI.

## Provider strategy
Use no-key, browser-native, local-first, and open-source options first. Add API-key fields for providers that require keys. Add fallback switching so the site can route around failures where possible. Do not promise zero lag. Provider speed depends on external service, model, API limits, network, browser restrictions, and returned file size.

## Provider matrix
| Group | Provider | Key requirement | Planned use | Limitation |
|---|---|---|---|---|
| Browser local tools / File API, Canvas, HTMLMediaElement, MediaRecorder, Web Speech, WebCodecs where available / No external key / Upload, inspect, preview, record, speak, media analysis, local repair exports / Works only inside browser capability limits. WebCodecs support varies by browser. |
| Local AI Help / Ollama local endpoint / No cloud key, local install required / Local AI helper and private text reasoning if user installs local model / Requires user-run local service and CORS permission. |
| Local image and animation / ComfyUI local endpoint / No cloud key, local install required / Images, video/animation workflows, advanced visual AI workflows / Requires user-run ComfyUI and configured workflows. |
| Free/accessible creative API / Pollinations AI / Usually no key for basic use, subject to service limits / Text, image, audio/video experiments and fallback tests / Must be treated as experimental until a real file or URL is returned. |
| Model hub/API / Hugging Face Inference Providers or Spaces / May require account/token depending provider/model / Text, image, speech, video model tests and fallback integrations / Provider behavior and cost vary by model/provider. |
| Paid fallback / Replicate official and public models / API token required / Image, video, audio, open-source model API fallback / Use for predictable hosted fallback, not default cheapest path. |
| Paid image provider / Stability AI platform / API key required / Stable Diffusion 3.5 and related image generation / Use after local/no-key options or where consistent cloud generation is required. |
| Future paid video provider slot / fal.ai, Runway, Stability video, custom endpoint / Key required / Image-to-video and generated clip fallback / Must be added behind proof-required provider tests. |
| Voice local option / Web Speech, Piper local, Kokoro local / Web Speech no key, local TTS install for Piper/Kokoro / Read aloud, TTS, narration generation where supported / Local TTS requires local service or packaged model approach. |

## Alert levels
| Color | Label | Meaning | Next action |
|---|---|---|---|
| Green | Passed | Feature or check passed automated verification. | No action required. |
| Yellow | Needs Review | Something may be incomplete or unclear. | Review and decide next step. |
| Orange | Warning | Issue can affect security, usability, upload, or playback. | Prepare Fix or export developer task. |
| Red | Broken or Unsafe | Function fails or risk is high. | Stop. Do not deploy until fixed. |
| Gray | Not Tested | No evidence yet. | Run test or upload needed file. |
| Blue | Info | Context, explanation, or optional improvement. | Read if needed. |

## Build phases
| Phase | Name | Work | Acceptance test |
|---|---|---|---|
| 1 | Preserve v4.3 base | Keep every working v4.3 feature and test navigation before adding v5. | No regressions in v4.3 screens. |
| 2 | Add premium navigation and design system | Add Agent Lab, Builder Studio, Provider Center, Admin Ops, Notes, How-To. | All new pages visible, no broken tabs. |
| 3 | Build onsite Agent Lab | Live link tests, uploaded package tests, form tests, media tests, screening tests. | Agent Lab produces alert cards and reports. |
| 4 | Build PWA Builder Studio | Unzip, file tree, manifest editor, service worker editor, asset path repair, rebuild ZIP. | Uploaded PWA can be inspected and re-exported. |
| 5 | Build MoviePWA Studio | Poster front screen, Play, Resume, Rate, movie.json, scenes.json, media validation. | Sample MoviePWA exports and opens with poster front screen. |
| 6 | Build creative tools | VN-style scene editor, asset importer, timeline references, preview player. | Scene metadata can be edited and package re-exported. |
| 7 | Build Provider Center | Provider cards, no-key/local-first options, key fields, tests, fallback order. | Provider status never says working without real response/file/URL. |
| 8 | Build Admin Ops and alerts | Automated checks, color alerts, daily and weekly reports. | Reports generate with top 3 issues and next action. |
| 9 | Build Notes and How-To systems | Floating notes, tags, colors, attachments, section context, step guides. | Notes work from every section. How-To exists for every feature. |
| 10 | Final verification and package | Syntax check, file check, export check, live QA checklist, handoff docs. | Deliver ZIP plus build report and QA checklist. |

## Required v5 screens
- Dashboard upgrade
- Onsite Agent Lab
- PWA Builder Studio
- MoviePWA/CinePWA Studio
- Creative Tools Studio
- Provider Center
- Admin Operations Center
- Screening Center
- Alert Dashboard
- Floating Notes
- Universal How-To Help
- Reports and Exports
- Settings and Accessibility

## MoviePWA/CinePWA poster front screen
MoviePWA packages must support a poster-led front screen. The poster is the first visible screen. Premium modern typography and buttons appear at the bottom. Required buttons are Play, Resume, and Rate. Play starts the package, Resume continues from saved progress, and Rate opens a rating panel. The builder must validate poster image path, button handlers, saved progress storage, scene order, audio/video paths, subtitle paths, and offline media cache where intended.

## Notes system
A Notes button must be available across the app. Tapping Notes opens a floating Apple Notes-style pop-up over the current page. Users can type, paste, copy, tag, color-code, attach images, connect notes to the current section, export single notes, export all notes as JSON, export urgent notes, and export developer task notes. Color labels must include text labels for dyslexia-friendly use.

## How-To system
Every feature must have a Show Steps or How to use this button. Each guide must explain what the tool does, when to use it, what to click first, what not to click yet, what result to expect, what a warning means, and what to do next. The format must use short steps, not dense paragraphs.

## Non-goals and limitations
- Load Tasks cannot guarantee perfect AI provider uptime.
- Load Tasks cannot guarantee perfect nudity or profanity detection. Uncertain items must be Needs Human Review.
- Browser-only PWA execution cannot run scheduled tests after the browser is closed without an external runner or backend.
- Heavy video rendering may require provider APIs, local engine, cloud worker, or backend later.
- Private API key storage should not be considered production-grade without a backend or secure vault.

## Final acceptance criteria
- All v4.3 features remain available.
- All v5 navigation sections open without errors.
- A PWA ZIP can be uploaded, inspected, edited, rebuilt, and exported.
- Media-heavy packages detect images, video, audio, icons, subtitles, and poster files.
- MoviePWA sample package can be created and exported.
- Poster front screen shows Play, Resume, and Rate controls in the package scaffold.
- Provider Center lists no-key/local-first and key-required providers separately.
- Provider tests never mark working without real evidence.
- Admin Operations Center creates color-coded alerts and daily reports.
- Notes pop-up works from every section.
- Every tool has a dyslexia-friendly How-To guide.
- All reports include top issues, what passed, what needs review, and next best action.
- No Complete status appears without evidence.
- Final package includes verification report and upload instructions.

## Sources
- Existing Load Studio manual: package structure, player, export/reopen, validation, CSP, provider proof rule, local engine direction.
- ComfyUI official GitHub and Comfy site: modular visual AI workflows for images, video, audio, and more.
- Hugging Face Inference Providers and Spaces: model/API ecosystem for AI tasks.
- Replicate official docs/pricing: hosted official and public models with API tokens and pay-per-use pricing.
- Stability AI Stable Diffusion 3.5 and API docs: open model variants and hosted image generation.
- MDN File API, MediaRecorder, Web Speech, WebCodecs: browser-native file, media, speech, and video processing capabilities.
- Ollama API docs: local LLM endpoint option.
- Piper and Kokoro repositories: local TTS options.
- Pollinations site and repository: accessible generative AI API approach.