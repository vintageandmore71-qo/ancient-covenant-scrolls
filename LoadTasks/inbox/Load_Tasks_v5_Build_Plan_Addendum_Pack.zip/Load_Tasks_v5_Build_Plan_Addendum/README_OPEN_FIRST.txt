Load Tasks v5 Build Plan Addendum

Open the DOCX for editable planning.
Open the PDF for fixed layout review.
Open the MD file for copy-paste into a builder or developer workspace.
Use the provider matrix, phase plan, and alert level CSV files for implementation tracking.

This is a build plan addition to the existing Load Studio PWA Cinema Experience manual. It is not the v5 app build itself.
