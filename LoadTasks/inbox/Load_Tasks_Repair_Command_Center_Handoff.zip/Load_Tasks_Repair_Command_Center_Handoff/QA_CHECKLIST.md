# Load Tasks Repair Command Center QA Checklist

## Before testing

- Open the app from HTTPS.
- Use a real test ZIP.
- Keep one clean backup ZIP.

## Test 1: App opens

Pass if:
- splash screen opens
- dashboard opens
- Fix Studio opens
- no raw code is shown

## Test 2: Upload package

Pass if:
- ZIP uploads
- app lists files
- app detects index.html
- app detects manifest.json
- app detects service-worker.js

## Test 3: GitHub Pages flatten

Pass if:
- button creates flat export
- index.html is at root
- .nojekyll exists
- 404.html exists
- upload instructions are generated

## Test 4: Duplicate IDs

Pass if:
- duplicate IDs are detected
- patch renames later duplicates
- report lists changed IDs
- status says Patched, Needs QA

## Test 5: Placeholder links

Pass if:
- href="#" links are detected
- safe placeholders convert to buttons
- handler stubs are added
- missing real functions become developer tasks

## Test 6: CSP

Pass if:
- CSP meta tag is added
- site still loads
- GitHub API is allowed only when GitHub push is enabled

## Test 7: iPad icon

Pass if:
- apple-touch-icon.png is exported
- index.html includes Apple icon links
- icon URL opens directly
- old shortcut is deleted and new shortcut shows icon

## Test 8: Repair Pack

Pass if ZIP contains:
- repaired-files
- reports
- prompts
- rollback
- manifest-of-changes.json

## Test 9: No false complete

Pass if:
- patched items say Patched, Needs QA
- developer-required items stay Developer Required
- complete appears only after verification

## Test 10: Dyslexia mode

Pass if:
- font size changes
- line spacing changes
- high contrast works
- reduced motion works
- guided repair wizard is readable
