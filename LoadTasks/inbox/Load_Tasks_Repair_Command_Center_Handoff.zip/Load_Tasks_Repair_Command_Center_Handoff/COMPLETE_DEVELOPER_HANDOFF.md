# Load Tasks Repair Command Center: Complete Developer Handoff

## Product name

Load Tasks

## Upgrade name

Repair Command Center

## Existing screen

Fix Studio currently separates:

- Safe auto-fixes
- Developer-required fixes

## Upgrade goal

Turn every detected issue into an action workflow.

Each issue card should have these controls:

- Explain
- Prepare Fix
- Apply Safe Patch
- Export Developer Task
- Create GitHub Issue
- Mark Patched, Needs QA
- Mark Verified only after test passes

## Required confidence labels

Every repair item must show one confidence label.

### Safe

The app can patch it with low risk.

Examples:

- Add README file
- Add SECURITY file
- Add 404 fallback page
- Add .nojekyll
- Add missing root Apple icon file

### Safe with Review

The app can patch it, but the user or developer must test it.

Examples:

- Duplicate HTML IDs
- Missing CSP meta tag
- Nested folder flattening
- Asset path repair
- Empty link conversion

### Instruction Only

The app should not change files. It should export a task and repair prompt.

Examples:

- Buttons with unclear intended actions
- Broken navigation that needs design decisions
- Missing pages that require new content

### Developer Required

The app should create a developer task only.

Examples:

- login
- payment
- database
- API integrations
- AI provider calls
- YouTube channel integration
- moderation system
- GitHub OAuth

### Blocked

The app cannot proceed because a required file or permission is missing.

Examples:

- no index.html
- no upload package
- no GitHub token when push is requested
- no file matching a missing asset reference

## Required automation workflows

### 1. Nested app root and GitHub Pages 404 repair

Problem:

The app package may contain index.html inside a nested folder. GitHub Pages may publish the wrong root, causing a 404 error.

Button:

Flatten for GitHub Pages

The app should:

1. Find the folder containing index.html.
2. Move that folder’s contents to the export root.
3. Add .nojekyll.
4. Add 404.html.
5. Keep assets, docs, templates, and sample-data.
6. Rewrite simple relative paths if needed.
7. Generate GitHub Pages instructions.
8. Export a fixed flat ZIP.
9. Mark as Patched, Needs QA.

Acceptance test:

- index.html is at the export root.
- manifest.json is at the export root.
- service-worker.js is at the export root.
- assets folder is present.
- 404.html is present.
- .nojekyll is present.

### 2. Duplicate HTML ID repair

Problem:

Duplicate IDs can break forms, labels, JavaScript, and accessibility.

Button:

Fix Duplicate IDs

The app should:

1. Scan HTML files for duplicate id values.
2. Keep the first instance unchanged.
3. Rename later duplicates using suffixes.
4. Example: bookingOccasion becomes bookingOccasion_2.
5. Update matching label for attributes where safe.
6. Report each changed ID.
7. Flag JavaScript references for developer review.
8. Mark as Patched, Needs QA.

Acceptance test:

- no duplicate IDs remain in patched HTML.
- labels still point to valid IDs.
- report lists every changed ID.

### 3. Empty links and placeholder actions

Problem:

href="#" links and buttons without handlers look functional but do nothing.

Buttons:

- Convert Empty Links to Safe Buttons
- Generate Handler Stubs
- Export Missing Function Tasks

The app should detect:

- href="#"
- href="javascript:void(0)"
- empty href
- buttons with no type
- buttons with no handler
- data-action values with no matching function
- links pointing to missing sections

Safe patch:

Replace obvious placeholder anchors with buttons.

Example before:

<a href="#">Upload Build</a>

Example after:

<button type="button" data-action="upload-build">Upload Build</button>

Add handler stub:

document.querySelectorAll("[data-action]").forEach((button) => {
  button.addEventListener("click", () => {
    console.warn("Action needs implementation:", button.dataset.action);
  });
});

Important:

Do not mark the real feature complete. Mark as Patched, Needs QA.

### 4. CSP repair

Problem:

A static PWA without a CSP is more exposed to unsafe scripts and injection mistakes.

Button:

Add Static PWA CSP

The app should add this to the head when safe:

<meta http-equiv="Content-Security-Policy" content="default-src 'self'; img-src 'self' data: blob:; media-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self' https://api.github.com; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self';">

Rules:

- If GitHub push is disabled, connect-src can be self only.
- If the site uses external APIs, list them before applying.
- Mark as Safe with Review.
- Do not mark complete until the app is opened and tested.

### 5. Root Apple icon repair

Problem:

iPad Safari may ignore manifest icons and show a plain letter icon.

Button:

Fix iPad Home Screen Icon

The app should:

1. Look for a 180x180 or 192x192 app icon.
2. Copy it to root as apple-touch-icon.png.
3. Insert Apple icon links into index.html.
4. Insert mobile web app meta tags.
5. Export patched index.html and apple-touch-icon.png.
6. Add instructions to delete the old Home Screen shortcut and re-add it.

Acceptance test:

Open this path:

/apple-touch-icon.png

If it loads, the icon exists.

### 6. Asset path repair

Problem:

Images, icons, audio, video, CSS, or JS may be referenced from the wrong path.

Button:

Repair Asset Paths

The app should:

1. Scan HTML, CSS, JS, manifest, and service worker references.
2. Build a file map.
3. Detect missing references.
4. Search the package for the same filename.
5. If exactly one match exists, repair the path.
6. If multiple matches exist, ask the user or create a developer task.
7. Export a path repair report.

Acceptance test:

- all repaired paths point to real files.
- unresolved files are listed clearly.

### 7. Repair Pack export

Button:

Create Repair Pack

The exported ZIP should contain:

repaired-files/
reports/repair-report.md
reports/developer-required-fixes.md
reports/qa-checklist.md
reports/github-upload-instructions.md
prompts/claude-repair-prompt.txt
prompts/human-developer-task-list.txt
rollback/
manifest-of-changes.json

### 8. Optional GitHub direct push

Button:

Push Safe Patch to GitHub

Fields:

- owner
- repo
- branch
- folder path
- fine-grained token

Safety rules:

- token must be session-only
- never save token to localStorage
- preview files before push
- create rollback ZIP before push
- push files one by one
- log every pushed file
- do not push blocked or developer-required fixes

### 9. GitHub issue creation

Button:

Create GitHub Issue

Each developer-required card should generate a GitHub issue with:

- title
- file path
- issue type
- evidence
- suggested repair
- acceptance criteria
- QA checklist
- priority label

## Status system

Allowed statuses:

- Detected
- Explained
- Prepared
- Patched, Needs QA
- Developer Required
- Blocked
- Verified
- Complete

Forbidden status:

- Complete without verification

## Dyslexia-friendly additions

The screen should support:

- short cards
- large buttons
- one action per button
- clear labels
- no dense paragraphs
- high contrast mode
- line spacing control
- font size control
- reduced motion mode
- plain language mode
- next best action panel
- read first summary
- color plus text labels
- progress steps
- simple repair wizard

## Dyslexia-friendly Repair Wizard

Add a wizard button:

Start Guided Repair

Steps:

1. What is broken?
2. What can be fixed safely?
3. What needs review?
4. Apply safe patches.
5. Export repair pack.
6. Upload to GitHub.
7. Test the live site.
8. Mark verified only if the test passes.

## Final verification rules

After applying a patch, Load Tasks should run these checks:

- required file exists
- modified file can be read
- patched HTML still has a head and body
- no duplicate IDs remain if duplicate ID repair was applied
- all repaired paths point to files
- index.html exists at export root if flattening was applied
- apple-touch-icon.png exists if iPad icon repair was applied
- generated report exists
- rollback ZIP exists

## Final builder instruction

Build this as a complete update to the existing Load Tasks PWA. Do not return fragments. Do not remove existing features. Keep the Load Tasks splash page, yellow glow design, premium dark interface, modern icons, and dyslexia-friendly settings.

Return a full standalone PWA ZIP.
