# READ FIRST: Load Tasks Repair Command Center

## Simple goal

Upgrade Load Tasks so the Fix Studio screen becomes a real Repair Command Center.

The app should not only say what is broken. It should:

1. Explain the problem.
2. Prepare the safest fix.
3. Apply simple safe patches.
4. Export a repair pack.
5. Create developer tasks for anything risky.
6. Optional: push safe patches to GitHub.
7. Never mark a build complete unless verified.

## The locked rule

No issue can be marked Complete unless Load Tasks verifies the file changed and the acceptance test passes.

If a fix was applied but not tested, the status must be:

Patched, Needs QA

## Best build order

1. Add issue action buttons.
2. Add repair confidence labels.
3. Add GitHub Pages flattening.
4. Add duplicate ID fixer.
5. Add empty link and button handler scanner.
6. Add CSP patch tool.
7. Add Apple icon fixer.
8. Add asset path repair.
9. Add Repair Pack export.
10. Add optional GitHub push and GitHub issue creation.

## What should stay developer-required

Do not fully auto-fix these without review:

- login
- payments
- database
- real API integrations
- AI provider calls
- YouTube integration
- nudity detection
- profanity detection
- legal compliance
- GitHub OAuth
- any form that collects private user data
