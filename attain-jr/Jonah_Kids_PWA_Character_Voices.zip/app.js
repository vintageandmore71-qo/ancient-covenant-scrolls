let deferredPrompt = null;
const installBtn = document.getElementById('installBtn');
const scenes = window.__SCENES__ || [];
const readerBox = document.getElementById('readerBox');
const sceneTitle = document.getElementById('sceneTitle');
const sceneButtons = [...document.querySelectorAll('.scene-nav button')];
const fontSize = document.getElementById('fontSize');
const copyScene = document.getElementById('copyScene');

function showScene(index){
  const scene = scenes[index] || scenes[0];
  if(!scene) return;
  sceneTitle.textContent = scene.title;
  readerBox.textContent = scene.text;
  sceneButtons.forEach((btn, i) => btn.classList.toggle('active', i === index));
  localStorage.setItem('jonah-scene-index', String(index));
}

sceneButtons.forEach((btn, index) => btn.addEventListener('click', () => showScene(index)));
fontSize?.addEventListener('input', e => {
  document.documentElement.style.setProperty('--reader-size', `${e.target.value}px`);
  localStorage.setItem('jonah-font-size', e.target.value);
});
copyScene?.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(`${sceneTitle.textContent}\n\n${readerBox.textContent}`);
    copyScene.textContent = 'Copied';
    setTimeout(() => copyScene.textContent = 'Copy scene', 1200);
  } catch(e) {
    copyScene.textContent = 'Copy failed';
    setTimeout(() => copyScene.textContent = 'Copy scene', 1200);
  }
});

const savedSize = localStorage.getItem('jonah-font-size');
if(savedSize){
  document.documentElement.style.setProperty('--reader-size', `${savedSize}px`);
  if(fontSize) fontSize.value = savedSize;
}
const savedScene = Number(localStorage.getItem('jonah-scene-index') || 0);
showScene(Number.isFinite(savedScene) ? savedScene : 0);

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installBtn.hidden = false;
});

installBtn?.addEventListener('click', async () => {
  if(!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  installBtn.hidden = true;
});

if('serviceWorker' in navigator){
  window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js'));
}

const readStoryOnly = document.getElementById('readStoryOnly');
const pauseStory = document.getElementById('pauseStory');
const stopStory = document.getElementById('stopStory');
const voiceMode = document.getElementById('voiceMode');
let availableVoices = [];
let speakingQueue = [];
let queueIndex = 0;
let currentUtterance = null;
let isCastReading = false;
let lockedVoiceBank = null;

function loadVoices(){
  availableVoices = window.speechSynthesis ? speechSynthesis.getVoices() : [];
  lockedVoiceBank = null;
}
if('speechSynthesis' in window){
  loadVoices();
  speechSynthesis.onvoiceschanged = loadVoices;
}

function englishVoices(){
  loadVoices();
  return availableVoices.filter(v => (v.lang || '').toLowerCase().startsWith('en'));
}

function voiceScore(v, patterns){
  const name = (v.name || '').toLowerCase();
  let score = 0;
  patterns.forEach((pattern, index) => {
    if(pattern.test(name)) score += 100 - index;
  });
  if(/premium|enhanced|siri|natural/.test(name)) score += 8;
  return score;
}

function pickDistinctVoice(patterns, used){
  const voices = englishVoices();
  if(!voices.length) return null;
  const ranked = voices
    .map(v => ({v, score: voiceScore(v, patterns)}))
    .sort((a,b) => b.score - a.score);
  const matched = ranked.find(x => x.score > 0 && !used.has(x.v.voiceURI || x.v.name));
  const unused = ranked.find(x => !used.has(x.v.voiceURI || x.v.name));
  const chosen = matched || unused || ranked[0];
  used.add(chosen.v.voiceURI || chosen.v.name);
  return chosen.v;
}

function buildLockedVoiceBank(){
  if(lockedVoiceBank) return lockedVoiceBank;
  const used = new Set();
  const bank = {};

  bank.narrator = pickDistinctVoice([/samantha/, /ava/, /victoria/, /karen/, /moira/, /zira/, /female/], used);
  bank.god = pickDistinctVoice([/daniel/, /fred/, /arthur/, /tom/, /ralph/, /male/, /alex/], used);
  bank.jonah = pickDistinctVoice([/alex/, /daniel/, /tom/, /fred/, /arthur/, /male/], used);
  bank.captain = pickDistinctVoice([/fred/, /tom/, /ralph/, /arthur/, /daniel/, /alex/, /male/], used);
  bank.king = pickDistinctVoice([/arthur/, /daniel/, /alex/, /fred/, /tom/, /male/], used);
  bank.child = pickDistinctVoice([/junior/, /nicky/, /samantha/, /ava/, /victoria/, /alex/, /oliver/], used);
  bank.child2 = pickDistinctVoice([/nicky/, /junior/, /ava/, /victoria/, /samantha/, /oliver/, /alex/], used);
  bank.male2 = pickDistinctVoice([/tom/, /alex/, /daniel/, /fred/, /arthur/, /male/], used);
  bank.female2 = pickDistinctVoice([/ava/, /victoria/, /karen/, /samantha/, /female/], used);

  lockedVoiceBank = bank;
  return bank;
}

function pickVoice(mode){
  const bank = buildLockedVoiceBank();
  if(mode === 'girl') return bank.female2 || bank.narrator;
  if(mode === 'boy') return bank.child || bank.jonah;
  if(mode === 'child') return bank.child || bank.child2 || bank.narrator;
  return bank.narrator || englishVoices()[0] || null;
}

const characterStyles = {
  narrator: { bank: 'narrator', rate: 0.94, pitch: 1.02 },
  jonah: { bank: 'jonah', rate: 0.92, pitch: 0.9 },
  god: { bank: 'god', rate: 0.78, pitch: 0.66 },
  captain: { bank: 'captain', rate: 1.0, pitch: 0.88 },
  seaman1: { bank: 'male2', rate: 1.04, pitch: 0.96 },
  seaman2: { bank: 'child', rate: 1.08, pitch: 1.12 },
  seaman3: { bank: 'male2', rate: 0.98, pitch: 1.0 },
  sailor1: { bank: 'male2', rate: 1.12, pitch: 1.05 },
  sailor2: { bank: 'child2', rate: 1.15, pitch: 1.18 },
  woman: { bank: 'female2', rate: 1.04, pitch: 1.22 },
  fish: { bank: 'child', rate: 1.02, pitch: 1.28 },
  fish2: { bank: 'child2', rate: 1.08, pitch: 1.38 },
  whale: { bank: 'child', rate: 0.96, pitch: 0.95 },
  crab: { bank: 'child2', rate: 0.98, pitch: 0.82 },
  worm: { bank: 'child', rate: 1.12, pitch: 1.34 },
  king: { bank: 'king', rate: 0.9, pitch: 0.82 },
  band: { bank: 'male2', rate: 0.88, pitch: 1.0 }
};

function normalizeSpeaker(raw){
  const s = (raw || '').toLowerCase().replace(/[^a-z0-9# ]/g, ' ').replace(/\s+/g,' ').trim();
  if(!s) return 'narrator';
  if(/\b(yhwh|god|lord|el)\b/.test(s)) return 'god';
  if(s.includes('jonah') || s.includes('noah')) return 'jonah';
  if(s.includes('captain')) return 'captain';
  if(s.includes('sea man 1') || s.includes('sea man#1') || s.includes('sea man1')) return 'seaman1';
  if(s.includes('sea man 2') || s.includes('sea man#2') || s.includes('sea man2')) return 'seaman2';
  if(s.includes('sea man 3') || s.includes('sea man#3') || s.includes('sea man3')) return 'seaman3';
  if(s.includes('sailor 1') || s.includes('sailor#1')) return 'sailor1';
  if(s.includes('sailor 2') || s.includes('sailor#2')) return 'sailor2';
  if(s.includes('woman')) return 'woman';
  if(s.includes('fish 2') || s.includes('fish#2')) return 'fish2';
  if(s.includes('whale')) return 'whale';
  if(s.includes('fish') || s.includes('nemo')) return 'fish';
  if(s.includes('crab')) return 'crab';
  if(s.includes('worm')) return 'worm';
  if(s.includes('king')) return 'king';
  if(s.includes('band')) return 'band';
  return 'narrator';
}

function parseCastSegments(text){
  const lines = text.split(/\n+/).map(l => l.trim()).filter(Boolean);
  const segments = [];
  let currentSpeaker = 'narrator';

  for(const originalLine of lines){
    let line = originalLine.trim();

    const labelOnly = line.match(/^([A-Za-z][A-Za-z0-9 #.'()\-]{0,45})\s*:?$/);
    const colon = line.match(/^([A-Za-z][A-Za-z0-9 #.'()\-]{0,45})\s*:\s*(.*)$/);
    const dash = line.match(/^(YHWH|God|Lord|LORD|EL|Jonah|JONAH|Noah|NOAH|Captain|CAPTAIN|King|KING|Worm|WORM|Crab|CRAB|Fish|FISH|Nemo|NEMO)\s*[\-–]\s*(.*)$/i);
    const godSentence = line.match(/^(God|LORD|Lord|YHWH|EL)\s+(.+)$/i);

    if(dash){
      const speaker = normalizeSpeaker(dash[1]);
      const spoken = dash[2].trim();
      if(spoken) segments.push({speaker, text: spoken});
      currentSpeaker = 'narrator';
      continue;
    }

    if(colon){
      const speaker = normalizeSpeaker(colon[1]);
      const spoken = colon[2].trim();
      currentSpeaker = speaker;
      if(spoken){
        segments.push({speaker, text: spoken});
        currentSpeaker = 'narrator';
      }
      continue;
    }

    if(labelOnly && normalizeSpeaker(labelOnly[1]) !== 'narrator' && line.length < 48){
      currentSpeaker = normalizeSpeaker(labelOnly[1]);
      continue;
    }

    if(godSentence && !/^then\b/i.test(line)){
      segments.push({speaker: 'god', text: godSentence[2].trim()});
      currentSpeaker = 'narrator';
      continue;
    }

    segments.push({speaker: currentSpeaker, text: line});
    currentSpeaker = 'narrator';
  }
  return segments;
}

function makeUtterance(segment, singleMode){
  const u = new SpeechSynthesisUtterance(segment.text);
  const bank = buildLockedVoiceBank();

  if(singleMode){
    const voice = pickVoice(singleMode);
    if(voice) u.voice = voice;
    u.rate = singleMode === 'child' || singleMode === 'girl' || singleMode === 'boy' ? 0.92 : 0.96;
    u.pitch = singleMode === 'girl' ? 1.22 : singleMode === 'boy' ? 1.05 : singleMode === 'child' ? 1.18 : 1.0;
    u.volume = 1;
    return u;
  }

  const style = characterStyles[segment.speaker] || characterStyles.narrator;
  const voice = bank[style.bank] || bank.narrator || englishVoices()[0] || null;
  if(voice) u.voice = voice;
  u.lang = voice?.lang || 'en-US';
  u.rate = style.rate;
  u.pitch = style.pitch;
  u.volume = 1;
  return u;
}

function speakQueueNext(){
  if(!isCastReading || queueIndex >= speakingQueue.length){
    readerBox?.classList.remove('speaking');
    isCastReading = false;
    return;
  }
  const mode = voiceMode?.value || 'cast';
  currentUtterance = makeUtterance(speakingQueue[queueIndex], mode === 'cast' ? null : mode);
  currentUtterance.onstart = () => readerBox?.classList.add('speaking');
  currentUtterance.onend = () => {
    queueIndex += 1;
    speakQueueNext();
  };
  currentUtterance.onerror = () => {
    queueIndex += 1;
    speakQueueNext();
  };
  speechSynthesis.speak(currentUtterance);
}

function speakStoryOnly(){
  if(!('speechSynthesis' in window)){
    alert('Read aloud is not available in this browser. Try Safari or Chrome.');
    return;
  }
  speechSynthesis.cancel();
  loadVoices();
  buildLockedVoiceBank();
  const storyText = (readerBox?.textContent || '').trim();
  if(!storyText) return;
  const mode = voiceMode?.value || 'cast';
  speakingQueue = mode === 'cast' ? parseCastSegments(storyText) : [{speaker:'narrator', text:storyText}];
  queueIndex = 0;
  isCastReading = true;
  speakQueueNext();
}

readStoryOnly?.addEventListener('click', speakStoryOnly);
pauseStory?.addEventListener('click', () => {
  if(!('speechSynthesis' in window)) return;
  if(speechSynthesis.paused){
    speechSynthesis.resume();
    pauseStory.textContent = '⏸ Pause';
  }else{
    speechSynthesis.pause();
    pauseStory.textContent = '▶ Resume';
  }
});
stopStory?.addEventListener('click', () => {
  if('speechSynthesis' in window) speechSynthesis.cancel();
  isCastReading = false;
  speakingQueue = [];
  queueIndex = 0;
  readerBox?.classList.remove('speaking');
  if(pauseStory) pauseStory.textContent = '⏸ Pause';
});

sceneButtons.forEach(btn => btn.addEventListener('click', () => {
  if('speechSynthesis' in window) speechSynthesis.cancel();
  isCastReading = false;
  speakingQueue = [];
  queueIndex = 0;
  readerBox?.classList.remove('speaking');
  if(pauseStory) pauseStory.textContent = '⏸ Pause';
}));

let audioCtx = null;
let musicNodes = [];
let musicPlaying = false;

function createAudioCtx(){
  if(!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  return audioCtx;
}

function tone(freq, duration, type='sine', gain=0.08, delay=0){
  const ctx = createAudioCtx();
  const osc = ctx.createOscillator();
  const vol = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, ctx.currentTime + delay);
  vol.gain.setValueAtTime(0.0001, ctx.currentTime + delay);
  vol.gain.exponentialRampToValueAtTime(gain, ctx.currentTime + delay + 0.02);
  vol.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + delay + duration);
  osc.connect(vol);
  vol.connect(ctx.destination);
  osc.start(ctx.currentTime + delay);
  osc.stop(ctx.currentTime + delay + duration + 0.05);
}

function stormSfx(){
  [70, 85, 60, 95, 50].forEach((f,i)=>tone(f, .35, 'sawtooth', .06, i*.12));
  [180, 140, 220].forEach((f,i)=>tone(f, .16, 'triangle', .04, .08 + i*.18));
}

function whaleSfx(){
  tone(120, .8, 'sine', .09, 0);
  tone(85, .9, 'sine', .08, .25);
  tone(65, 1.0, 'sine', .07, .55);
}

function popSfx(){
  [440, 660, 880].forEach((f,i)=>tone(f, .12, 'triangle', .08, i*.07));
}

function startMusic(){
  const ctx = createAudioCtx();
  const gain = ctx.createGain();
  gain.gain.value = 0.035;
  gain.connect(ctx.destination);
  const notes = [146.83, 196.00, 220.00, 174.61];
  musicNodes = [];
  notes.forEach((freq, i) => {
    const osc = ctx.createOscillator();
    osc.type = i % 2 ? 'triangle' : 'sine';
    osc.frequency.value = freq;
    osc.connect(gain);
    osc.start();
    musicNodes.push(osc);
  });
  musicNodes.push(gain);
  musicPlaying = true;
}

function stopMusic(){
  musicNodes.forEach(node => { try { node.stop?.(); node.disconnect?.(); } catch(e){} });
  musicNodes = [];
  musicPlaying = false;
}

document.getElementById('stormBtn')?.addEventListener('click', stormSfx);
document.getElementById('whaleBtn')?.addEventListener('click', whaleSfx);
document.getElementById('popBtn')?.addEventListener('click', popSfx);
document.getElementById('musicBtn')?.addEventListener('click', (e) => {
  if(musicPlaying){
    stopMusic();
    e.currentTarget.textContent = '🎬 Cinematic music';
  } else {
    startMusic();
    e.currentTarget.textContent = '■ Stop music';
  }
});
