Jonah, The Man — Compressed Kids PWA

This is still a full PWA:
- index.html
- manifest.webmanifest
- service-worker.js
- offline cache
- cover/splash page
- dyslexia-friendly reader
- character voice read-aloud
- lightweight real sound effects and cinematic music using Web Audio

Open index.html for testing. For PWA install, host the folder or open through a local/static server, then Add to Home Screen in Safari.
