STOP LION KIDS PWA

Upload all files in this folder to the main branch/root of a GitHub repository.
Turn on GitHub Pages for the main branch.
Open the site link in Safari on iPad.
Tap Share, then Add to Home Screen.

Included:
- cover and splash page
- dyslexia-friendly colorful reading layout
- read-aloud controls using the browser speech voice
- tap-to-highlight lines
- focus mode
- font size controls
- sunny/night theme
- playful sound buttons
- offline cache after first load
