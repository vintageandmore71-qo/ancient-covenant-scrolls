
# Updated Addendum: AI Chat Studio, Multi-Style Image Generation, and Image Animation

## Why this addendum exists

The Load AI generator plan must explicitly include the chat-style creation surface that generates images in multiple styles and animates images. These features are not decorative. They are core to the LoadStudio movie/content pipeline.

The practical bridge is:

```text
source material → chat request → image generation → style control → image animation → scene building → PWA cinema package → LoadPlay-ready content
```

## Correct feature interpretation

The target is not a full copy of any outside app. The target is the chat-style creation pattern only:

```text
User types what they want.
User optionally uploads or references source material.
User chooses or describes a style.
System generates or refines an image.
System can animate a still image.
User saves the result into the project.
User attaches the result to a scene.
The output becomes part of a LoadStudio package.
```

## Core features to add explicitly

X-AI-CHAT-STUDIO must support:

1. Chat input box
2. Prompt refinement
3. Conversation history
4. Project-linked history
5. Output type selector
6. Text-to-image generation
7. Image-to-image generation
8. Multi-style image generation
9. Style selector
10. Reference image upload
11. Regenerate and variation tools
12. Save generated image to project
13. Attach generated image to scene
14. Animate still image
15. Image-to-video generation or motion-output support
16. Motion prompt input
17. Save animated output to project
18. Attach animation/video to scene
19. Output review
20. Prompt-only fallback

## Features not to build

Do not build the system around:

- beauty filters
- glamour effects
- makeover tools
- social-media-first trend features
- viral novelty effects
- face retouching as the main product

LoadStudio needs a production-grade creative system, not a toy effects app.

## Placement

### Load Main

Load Main owns the X-AI-CORE infrastructure:

- provider routing
- local/open-source/cloud-optional connectors
- capability detection
- diagnostics
- output proof
- rights metadata
- safety checks
- prompt-only fallback

### LoadStudio

LoadStudio owns X-AI-CHAT-STUDIO and X-STUDIO-AI:

- chat interface
- image generation
- image style control
- reference images
- image animation
- scene creation
- character/style/voice/wardrobe bibles
- package export

### LoadPlay

LoadPlay should not be the AI creation center. Later, it can use AI for moderation, metadata, recommendations, captions, thumbnails, and upload review.

## Movie/content workflow

The AI Chat Studio should support this movie-building flow:

```text
1. Import or reference book/script/source material.
2. Open Load AI Chat Studio.
3. Ask for a visual scene image.
4. Choose style or use project style bible.
5. Generate image or structured prompt.
6. Refine image through chat.
7. Animate the chosen image.
8. Attach still image or animation to a scene card.
9. Store output proof and rights metadata.
10. Save prompt and output history.
11. Export the project as .loadstudio.zip or .cinepwa.zip.
```

## Required structured outputs

The chat and generation system should write to:

```text
chat-history.json
prompt-log.json
generation-report.json
scene-plan.json
characters.json
style-bible.json
voice-bible.json
wardrobe-bible.json
rights.json
continuity-report.json
asset-declarations.json
```

## Non-negotiable output proof rules

```text
Never claim image generation succeeded unless a real file/blob/URL exists.
Never claim animated output succeeded unless a real playable file/blob/URL exists.
Never claim video generation succeeded unless a real playable file/blob/URL exists.
Never claim audio generation succeeded unless a playable file/blob exists.
Never claim text generation succeeded unless non-empty text exists.
Never claim ZIP/package generation succeeded unless the ZIP is real and valid.
Never claim a provider is ready unless a real test succeeds.
```

## Acceptance criteria addendum

The AI Chat Studio is not complete unless:

1. The chat interface opens inside LoadStudio.
2. The user can enter a creation request.
3. The user can choose image, animation, video prompt, scene prompt, or package-ready output.
4. The user can upload/reference an image.
5. The user can choose a style or use project style bible.
6. The system routes through X-AI-CORE.
7. The system returns a generated file/blob/URL or a structured fallback prompt.
8. The user can refine through chat.
9. The user can save output to project.
10. The user can attach output to a scene.
11. chat-history.json is created or updated.
12. prompt-log.json is created or updated.
13. generation-report.json is created or updated.
14. rights.json or asset-declarations.json is updated.
15. No success message appears without verified output.
