HOW TO OPEN THIS STANDALONE DIGITAL BOOK PWA

1. Unzip the folder.
2. Upload the full folder to your site, GitHub Pages, Netlify, Vercel, or your developer workspace.
3. Open index.html through a local server or hosted URL.
4. Do not open manifest.json, sw.js, or the CSS/JS source files directly. Those files will show code because they are supposed to be code.
5. The book app entry point is always index.html.

Files included:
- index.html: the actual digital book PWA
- manifest.json: PWA install settings
- sw.js: offline cache service worker
- assets/cover.jpg: compressed book cover
- assets/icon-192.png and icon-512.png: PWA icons
