# AI Chat Image and Animation Pattern Analysis for Load

Prepared for Claude handoff

## Purpose

This file defines the exact AI chat image-generation and image-animation behavior Load should build into LoadStudio.

The examples show a creation chat workflow, not a normal chatbot. The chat itself becomes the command center for image generation, refinement, image animation, progress states, final video output, save/export actions, project attachment, and scene attachment.

## Core pattern to build

User types request.
System generates image inside chat.
User refines image in chat.
User asks to animate the image.
System shows an in-progress animation state.
System returns playable video in chat.
User saves, exports, extends, refines, or attaches to scene.
System writes project metadata and reports.

## Required AI Chat Studio behavior

1. Natural-language prompt input.
2. Inline image result cards.
3. Text-to-image generation.
4. Image-to-image generation.
5. Multi-style image generation.
6. Style selector.
7. Reference image upload.
8. Regenerate and variation tools.
9. Save generated image to project.
10. Attach generated image to scene.
11. Follow-up command such as “Animate this.”
12. Animate still image.
13. Image-to-video generation or animation-ready prompt fallback.
14. Animation progress / waiting state.
15. Inline video result card.
16. Save generated animation/video to project.
17. Attach generated animation/video to scene.
18. Extend animation option.
19. Chat history per project.
20. Prompt-only fallback if no model is connected.

## Two animation levels required

### Level 1: Light image animation

- camera push-in
- gentle parallax
- soft environmental movement
- subtle portrait motion
- background light movement

### Level 2: Performance-style image animation

- head turns
- facial expression changes
- body movement
- hair/clothing motion
- identity preservation
- background/scene continuity

This second level is essential for movie/content production.

## Required output cards

### Image result card

Must include:

- title: Image Created
- sublabel: Text to Image or Image to Image
- preview image
- Save
- Export/share
- Feedback
- Attach to Project
- Attach to Scene
- Refine

### Animation pending card

Must include:

- title: Almost Ready or Animation in Progress
- sublabel: Video Animation
- source thumbnail
- progress indicator or status message

### Video result card

Must include:

- title: Video Created
- sublabel: Video Animation
- playable video or preview thumbnail
- Save
- Export/share
- Feedback
- Extend
- Attach to Project
- Attach to Scene

## Required structured files

Do not keep outputs only in chat. Save production data into:

- chat-history.json
- prompt-log.json
- generation-report.json
- rights.json
- asset-declarations.json
- scene-plan.json
- characters.json
- style-bible.json
- voice-bible.json
- wardrobe-bible.json
- continuity-report.json

The animated output must remain linked to:

- source image
- original prompt
- animation prompt
- provider/model used
- project
- scene if attached

## Non-negotiable proof rules

Do not claim image generation success unless a real file/blob/URL exists.
Do not claim animation or video success unless a real playable file/blob/URL exists.
Do not claim package success unless the ZIP is real and validated.

## Claude-ready instruction block

Claude, add the following interpretation to the Load AI build:

The desired AI chat pattern is a conversational generation workflow where outputs appear directly inside the chat thread.

Required behavior:
- user types a natural-language request
- system generates an image inline in chat
- system provides Save, Export, Feedback, Attach to Project, and Attach to Scene actions
- user can ask for refinements in the same thread
- user can ask to animate the image in the same thread
- system shows an animation processing state
- system returns the final playable animation in the chat
- user can save, extend, refine, export, attach to project, and attach to scene

Support two animation levels:

1. Light image animation:
   - subtle camera motion
   - gentle parallax
   - soft environmental motion

2. Performance-style image animation:
   - head movement
   - facial expression change
   - body movement
   - hair/clothing motion
   - scene continuity
   - identity preservation

Do not treat chat outputs as temporary only.
Write structured project data into:
- chat-history.json
- prompt-log.json
- generation-report.json
- rights.json
- asset-declarations.json
- scene-plan.json
- continuity-report.json

Do not claim image success unless a real file/blob/URL exists.
Do not claim animation success unless a real playable file/blob/URL exists.

## Final conclusion

Load should build AI chat-driven image generation and image-to-performance animation inside a project-aware, scene-aware, package-aware production system.

This is a core pillar of the Load content and movie pipeline.
