/* LOAD AI Output Verifier
   Prevents false success when providers return text instead of images.
*/

export function isProbablyImageUrl(value) {
  if (typeof value !== "string") return false;

  return (
    value.startsWith("data:image/") ||
    value.startsWith("blob:") ||
    /\.(png|jpg|jpeg|webp|gif)(\?.*)?$/i.test(value) ||
    value.includes("image")
  );
}

export function verifyImageProviderResult(result) {
  if (!result) {
    return fail("No result returned.");
  }

  if (result instanceof Blob && result.type.startsWith("image/")) {
    return pass("blob", result);
  }

  if (typeof File !== "undefined" && result instanceof File && result.type.startsWith("image/")) {
    return pass("file", result);
  }

  if (typeof result === "string") {
    if (isProbablyImageUrl(result)) return pass("url", result);
    return fail("Provider returned text instead of image.");
  }

  const candidates = [
    result.url,
    result.imageUrl,
    result.outputUrl,
    result.fileUrl,
    result.blobUrl
  ].filter(Boolean);

  for (const candidate of candidates) {
    if (isProbablyImageUrl(candidate)) return pass("url", candidate);
  }

  if (result.blob instanceof Blob && result.blob.type.startsWith("image/")) {
    return pass("blob", result.blob);
  }

  if (result.error) {
    return fail(`Provider error: ${result.error}`);
  }

  return fail("No image URL, blob, or file found in provider response.");
}

function pass(outputType, output) {
  return {
    success: true,
    outputType,
    output,
    reason: "Actual image returned."
  };
}

function fail(reason) {
  return {
    success: false,
    outputType: "none",
    output: null,
    reason
  };
}

export function createOutputReceipt({
  prompt,
  negativePrompt,
  provider,
  model,
  seed,
  taskType,
  referenceImageId,
  consistencyMode,
  sourceImageId,
  output,
  verification
}) {
  return {
    prompt,
    negativePrompt,
    provider,
    model,
    seed: seed || null,
    taskType,
    referenceImageId: referenceImageId || null,
    consistencyMode,
    sourceImageId: sourceImageId || null,
    outputFileOrUrl: typeof output === "string" ? output : "[blob/file]",
    verificationResult: verification,
    dateTime: new Date().toISOString()
  };
}
