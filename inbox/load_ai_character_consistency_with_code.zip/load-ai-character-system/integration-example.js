/* LOAD AI Integration Example
   This shows how to connect the router without rebuilding the app.
*/

import { runImageTask } from "./image-router.js";
import { saveCharacterProfile, getCharacterProfile } from "./character-memory.js";

// Example: save a character once.
saveCharacterProfile({
  id: "jonah_v1",
  name: "Jonah",
  referenceImageId: "jonah_ref_001",
  referenceImageUrl: "./assets/references/jonah.png",
  faceStructure: "consistent long face, strong brow, defined nose and jaw",
  skinTone: "warm brown",
  ageRange: "young adult",
  hair: {
    style: "long loose curls",
    length: "long",
    texture: "curly",
    color: "dark brown"
  },
  eyes: {
    shape: "almond",
    color: "dark brown"
  },
  bodyType: "lean athletic",
  clothingStyle: "ancient linen robe and earth-toned cloak",
  lightingStyle: "cinematic warm natural light",
  cameraStyle: "medium cinematic framing",
  artStyle: "historical cinematic realism",
  seed: 123456,
  consistencyMode: "strict"
});

// Example provider client stubs.
// Replace these with your existing provider calls.
const providerClients = {
  pollinations: {
    async run({ prompt, seed }) {
      const encoded = encodeURIComponent(prompt);
      return `https://image.pollinations.ai/prompt/${encoded}?seed=${seed || 123456}`;
    }
  },

  huggingface: {
    async run(payload) {
      // Replace with your existing HF call.
      // Must return an image blob/file/url, not text.
      throw new Error("Hugging Face client not connected.");
    }
  },

  cloudflare: {
    async run(payload) {
      // Replace with your Cloudflare Worker call.
      throw new Error("Cloudflare client not connected.");
    }
  }
};

// Example: improve an existing image.
export async function improveCurrentImage(sourceImage) {
  const characterProfile = getCharacterProfile("jonah_v1");

  return await runImageTask({
    taskType: "improve",
    userPrompt: "Improve clarity and sharpness without changing identity.",
    characterProfile,
    sourceImage,
    consistencyMode: "strict",
    providerClients
  });
}

// Example: add another person to the current image.
export async function addPersonToCurrentImage(sourceImage, maskImage) {
  const characterProfile = getCharacterProfile("jonah_v1");

  return await runImageTask({
    taskType: "add_person",
    userPrompt: "Add an older sailor standing behind Jonah on the left side, matching the same lighting and historical style.",
    characterProfile,
    sourceImage,
    maskImage,
    consistencyMode: "strict",
    providerClients
  });
}
