/* LOAD AI Prompt Builder
   Builds strong prompts for character consistency and image editing.
*/

import { buildCharacterLock } from "./character-memory.js";

const BASE_NEGATIVE = [
  "different person",
  "new face",
  "face change",
  "wrong identity",
  "distorted face",
  "blurry",
  "soft focus",
  "low resolution",
  "deformed",
  "extra limbs",
  "wrong body",
  "wrong hair",
  "wrong outfit",
  "inconsistent style"
];

export function buildImagePrompt({
  taskType,
  userPrompt,
  characterProfile = null,
  consistencyMode = "strict",
  editTarget = "",
  sceneNotes = ""
}) {
  const characterLock = buildCharacterLock(characterProfile);

  const strictness =
    consistencyMode === "strict"
      ? "Preserve identity exactly. Do not alter face, body proportions, outfit continuity, or character-defining features."
      : consistencyMode === "moderate"
      ? "Preserve identity and major features. Minor stylistic variation is acceptable."
      : "Preserve general identity and style.";

  const taskInstruction = getTaskInstruction(taskType, editTarget);

  const prompt = [
    taskInstruction,
    characterLock,
    strictness,
    sceneNotes,
    userPrompt
  ].filter(Boolean).join("\n");

  const negativePrompt = BASE_NEGATIVE.join(", ");

  return {
    prompt,
    negativePrompt,
    consistencyMode,
    taskType
  };
}

function getTaskInstruction(taskType, editTarget) {
  switch (taskType) {
    case "improve":
      return "Improve clarity and detail while preserving the original image, identity, composition, lighting, and style. Use low-strength enhancement only.";
    case "add_person":
      return "Add a new person into the selected area. Match lighting, perspective, camera angle, image quality, and scene style. Do not change existing characters.";
    case "modify_character":
      return `Modify only ${editTarget || "the requested target"}. Keep the same character, same face, and same identity.`;
    case "change_background":
      return "Replace only the background. Keep the subject identical. Match lighting direction and perspective.";
    case "remove_object":
      return "Remove only the selected object. Fill naturally and preserve surrounding detail.";
    case "outpaint":
      return "Extend the scene naturally. Match existing perspective, lighting, style, and depth. Do not change the existing subject.";
    case "inpaint":
      return "Edit only the masked area. Preserve all unmasked areas exactly.";
    case "img2img":
      return "Use the source image as the foundation. Preserve identity, pose, composition, and style.";
    default:
      return "Generate the requested image while following all character consistency rules.";
  }
}

export function buildExternalToolPrompt({ prompt, negativePrompt, referenceImageInstructions = "", seed = null, strength = 0.35 }) {
  return {
    tool: "Stable Diffusion / ComfyUI / Fooocus / Automatic1111",
    positivePrompt: prompt,
    negativePrompt,
    referenceImageInstructions,
    img2imgStrength: strength,
    seed: seed || "reuse previous seed if available",
    notes: "Use img2img or inpainting for preservation. Do not use pure text-to-image for edits."
  };
}
