# LOAD AI — Character Consistency + Image Editing System

## Purpose

Maintain consistent characters across image generations and enable controlled edits to existing images using free or free-tier providers.

This package includes:
- A developer guide
- Character profile schema
- Provider capability registry
- Prompt builder
- Image task router
- Output verifier
- Example integration code

---

## 1. Character Consistency System

### Core Rule

Never rely on text-only generation for strong character consistency.

Always prefer:
- image-to-image
- inpainting
- masked editing
- reference-image workflows

Text-to-image can be used only for loose generation.

---

## 1.1 Character Profile

Each character should be stored as a reusable profile:

- referenceImageId
- faceStructure
- skinTone
- ageRange
- hair
- eyes
- bodyType
- clothingStyle
- lightingStyle
- cameraStyle
- artStyle
- seed
- consistencyMode

Consistency modes:
- strict: reject face or body drift
- moderate: allow small variation
- loose: allow style variation

---

## 1.2 Required Prompt Injection

Add to every character task:

same character, same face, same person, identical facial features, consistent identity, no face variation, no body variation

---

## 1.3 Negative Prompt

Always include:

different person, new face, face change, distorted face, blurry, deformed, extra limbs, inconsistent identity, wrong body, wrong hair, wrong outfit

---

## 1.4 Provider Rules

Before calling a provider:

- If provider does not support image input, mark as LOW consistency.
- If editing is requested, do not use text-to-image.
- If provider returns text instead of an image, mark failed.
- If identity changes, reject and retry next provider.

---

## 1.5 Seed Control

If provider supports seed:
- reuse the same seed for the same character.

If provider does not support seed:
- strengthen the prompt.
- require reference image input where possible.

---

## 1.6 Verification Step

After generation, check:
- face shape
- hair
- skin tone
- clothing
- body proportions
- style
- blur or softness
- whether an actual image was returned

If mismatch:
- reject result
- try next provider

---

# 2. Image Editing System

## Core Rule

Edits must use the existing image as input.

Do not regenerate the whole image from scratch unless the user explicitly asks.

---

## 2.1 Supported Edit Types

- improve quality
- sharpen or upscale
- add person
- remove object
- change background
- change clothing
- fix face
- extend image
- modify pose
- adjust lighting

---

## 2.2 Editing Flow

1. Load existing image.
2. Select edit type.
3. Determine whether this is:
   - full image edit
   - masked edit
   - inpainting
   - image-to-image
4. Build exact edit prompt.
5. Send to provider.
6. Verify output.
7. Retry if needed.
8. If all fail, return external-tool prompt.

---

## 2.3 Improve Image

Use low-strength image-to-image if available.

Suggested strength:
- 0.2 to 0.4

Prompt:

Improve clarity and detail while preserving the exact same character, face, body, pose, composition, lighting, and style. Sharpen gently. Do not change identity.

---

## 2.4 Add Another Person

Use inpainting or masked edit.

Prompt:

Add a second person standing beside the original character. Match the same lighting, perspective, scene style, camera angle, and image quality. Do not change the original character. Preserve the original character's face, body, outfit, pose, and expression exactly.

Rules:
- original character must not change
- new person must match scene style
- use a mask or selected region when possible

---

## 2.5 Modify Existing Character

Use image-to-image or mask.

Prompt:

Same person, same face, same identity. Modify only [target change]. Keep facial features, body proportions, clothing continuity, lighting, and art style consistent.

Examples:
- change clothing
- adjust expression
- slight pose shift
- add accessory

---

## 2.6 Background Change

Use subject mask.

Prompt:

Keep the subject identical. Replace only the background with [new background]. Match lighting direction, perspective, depth, and style.

---

## 2.7 Remove Object

Use mask/inpainting.

Prompt:

Remove the selected object and fill the area naturally. Preserve surrounding details, lighting, texture, and perspective.

---

## 2.8 Extend Image

Use outpainting where supported.

Prompt:

Extend the scene naturally beyond the current frame. Match perspective, lighting, style, textures, and depth. Do not change the existing character or central subject.

---

# 3. Free Provider Strategy

Provider priority:
1. Hugging Face image-to-image or inpainting if available
2. Cloudflare image models if enabled
3. AI Horde, variable quality
4. Pollinations, generation only
5. DeepAI, Together, or other free-credit providers as fallback only

Important:
Pollinations should not be trusted for strict preservation unless it supports reference image handling for the selected task.

---

# 4. Failure Rules

If a provider returns:
- plain text
- markdown
- JSON only
- explanation
- error message
- no file
- no blob
- no image URL

Then:
- mark provider failed
- try next provider
- do not call it success

---

# 5. AI Output Receipt

Every generation or edit should store:

- prompt
- negativePrompt
- provider
- model
- seed
- taskType
- referenceImageId
- consistencyMode
- sourceImageId
- outputFileOrUrl
- verificationResult
- dateTime

---

# 6. External Tool Export

If all free providers fail, return an external prompt for:
- ComfyUI
- Stable Diffusion
- Fooocus
- Automatic1111
- Leonardo
- Midjourney
- Runway
- Kling
- Pika

Include:
- positive prompt
- negative prompt
- reference image instructions
- img2img strength
- seed notes
- mask notes if needed

---

# 7. Files in This Package

- character-profile-schema.json
- provider-registry.js
- character-memory.js
- prompt-builder.js
- output-verifier.js
- image-router.js
- integration-example.js

---

# 8. Developer Instruction

Install these files into the Load AI image editor module.

Do not rebuild the app.

Use the router before every image request.
Use the verifier after every image response.
Never report success unless an actual image URL, blob, or file is returned.
