/* LOAD AI Character Memory
   Store and retrieve locked character profiles.
*/

const STORAGE_KEY = "load_ai_character_profiles_v1";

export function getAllCharacterProfiles() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
  } catch {
    return {};
  }
}

export function getCharacterProfile(characterId) {
  const profiles = getAllCharacterProfiles();
  return profiles[characterId] || null;
}

export function saveCharacterProfile(profile) {
  if (!profile || !profile.id) {
    throw new Error("Character profile requires an id.");
  }

  const profiles = getAllCharacterProfiles();
  profiles[profile.id] = {
    ...profile,
    updatedAt: new Date().toISOString()
  };

  localStorage.setItem(STORAGE_KEY, JSON.stringify(profiles));
  return profiles[profile.id];
}

export function buildCharacterLock(profile) {
  if (!profile) return "";

  const hair = profile.hair
    ? `${profile.hair.color || ""} ${profile.hair.texture || ""} ${profile.hair.length || ""} ${profile.hair.style || ""}`.trim()
    : "";

  const eyes = profile.eyes
    ? `${profile.eyes.color || ""} ${profile.eyes.shape || ""}`.trim()
    : "";

  return [
    `Character identity lock: ${profile.name || profile.id}`,
    profile.faceStructure ? `face structure: ${profile.faceStructure}` : "",
    profile.skinTone ? `skin tone: ${profile.skinTone}` : "",
    profile.ageRange ? `age range: ${profile.ageRange}` : "",
    hair ? `hair: ${hair}` : "",
    eyes ? `eyes: ${eyes}` : "",
    profile.bodyType ? `body type: ${profile.bodyType}` : "",
    profile.clothingStyle ? `clothing style: ${profile.clothingStyle}` : "",
    profile.lightingStyle ? `lighting style: ${profile.lightingStyle}` : "",
    profile.cameraStyle ? `camera style: ${profile.cameraStyle}` : "",
    profile.artStyle ? `art style: ${profile.artStyle}` : "",
    "same character, same face, same person, identical facial features, consistent identity, no variation"
  ].filter(Boolean).join(". ");
}
