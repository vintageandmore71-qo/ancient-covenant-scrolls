/* LOAD AI Image Router
   Routes image tasks to the safest available provider.
*/

import { getProviderOrder } from "./provider-registry.js";
import { buildImagePrompt, buildExternalToolPrompt } from "./prompt-builder.js";
import { verifyImageProviderResult, createOutputReceipt } from "./output-verifier.js";

export async function runImageTask({
  taskType,
  userPrompt,
  characterProfile = null,
  sourceImage = null,
  maskImage = null,
  consistencyMode = "strict",
  editTarget = "",
  sceneNotes = "",
  providerClients = {},
  modelPreferences = {}
}) {
  const needsStrictConsistency = consistencyMode === "strict" || !!characterProfile?.referenceImageUrl;

  const built = buildImagePrompt({
    taskType,
    userPrompt,
    characterProfile,
    consistencyMode,
    editTarget,
    sceneNotes
  });

  const providerOrder = getProviderOrder(taskType, needsStrictConsistency);

  const failures = [];

  for (const providerKey of providerOrder) {
    const client = providerClients[providerKey];

    if (!client || typeof client.run !== "function") {
      failures.push({ provider: providerKey, reason: "Provider client missing." });
      continue;
    }

    try {
      const result = await client.run({
        taskType,
        prompt: built.prompt,
        negativePrompt: built.negativePrompt,
        sourceImage,
        maskImage,
        referenceImage: characterProfile?.referenceImageUrl || null,
        seed: characterProfile?.seed || null,
        model: modelPreferences[providerKey] || null,
        consistencyMode
      });

      const verification = verifyImageProviderResult(result);

      if (!verification.success) {
        failures.push({ provider: providerKey, reason: verification.reason });
        continue;
      }

      const receipt = createOutputReceipt({
        ...built,
        provider: providerKey,
        model: modelPreferences[providerKey] || null,
        seed: characterProfile?.seed || null,
        referenceImageId: characterProfile?.referenceImageId || null,
        sourceImageId: sourceImage?.id || null,
        output: verification.output,
        verification
      });

      return {
        success: true,
        provider: providerKey,
        output: verification.output,
        receipt,
        failures
      };
    } catch (error) {
      failures.push({ provider: providerKey, reason: error.message || String(error) });
    }
  }

  const externalPrompt = buildExternalToolPrompt({
    prompt: built.prompt,
    negativePrompt: built.negativePrompt,
    referenceImageInstructions: characterProfile?.referenceImageUrl
      ? `Use this reference image for identity: ${characterProfile.referenceImageUrl}`
      : "Attach the closest character reference image.",
    seed: characterProfile?.seed || null,
    strength: taskType === "improve" ? 0.25 : 0.35
  });

  return {
    success: false,
    reason: "No provider returned a valid image.",
    failures,
    externalPrompt
  };
}
