/* LOAD AI Provider Capability Registry
   Purpose: prevent wrong provider routing and reduce blurry/inconsistent image results.
*/

export const PROVIDER_REGISTRY = {
  pollinations: {
    name: "Pollinations",
    freeStatus: "free",
    requiresKey: false,
    runsInBrowser: true,
    supportsTextToImage: true,
    supportsImageInput: false,
    supportsImageOutput: true,
    supportsImg2Img: false,
    supportsInpainting: false,
    supportsMasks: false,
    supportsReferenceImage: false,
    supportsSeed: true,
    preservationLevel: "low"
  },

  huggingface: {
    name: "Hugging Face",
    freeStatus: "free-tier",
    requiresKey: true,
    runsInBrowser: false,
    supportsTextToImage: true,
    supportsImageInput: true,
    supportsImageOutput: true,
    supportsImg2Img: true,
    supportsInpainting: true,
    supportsMasks: true,
    supportsReferenceImage: true,
    supportsSeed: "model-dependent",
    preservationLevel: "medium-high"
  },

  cloudflare: {
    name: "Cloudflare Workers AI",
    freeStatus: "free-tier",
    requiresKey: true,
    runsInBrowser: false,
    supportsTextToImage: true,
    supportsImageInput: "model-dependent",
    supportsImageOutput: true,
    supportsImg2Img: "model-dependent",
    supportsInpainting: "model-dependent",
    supportsMasks: "model-dependent",
    supportsReferenceImage: "model-dependent",
    supportsSeed: "model-dependent",
    preservationLevel: "medium"
  },

  aiHorde: {
    name: "AI Horde",
    freeStatus: "free-anonymous-or-key",
    requiresKey: false,
    runsInBrowser: true,
    supportsTextToImage: true,
    supportsImageInput: "worker-dependent",
    supportsImageOutput: true,
    supportsImg2Img: "worker-dependent",
    supportsInpainting: "worker-dependent",
    supportsMasks: "worker-dependent",
    supportsReferenceImage: "worker-dependent",
    supportsSeed: true,
    preservationLevel: "variable"
  },

  deepai: {
    name: "DeepAI",
    freeStatus: "free-tier",
    requiresKey: true,
    runsInBrowser: false,
    supportsTextToImage: true,
    supportsImageInput: "limited",
    supportsImageOutput: true,
    supportsImg2Img: "limited",
    supportsInpainting: false,
    supportsMasks: false,
    supportsReferenceImage: false,
    supportsSeed: false,
    preservationLevel: "low-medium"
  },

  together: {
    name: "Together AI",
    freeStatus: "free-credit-if-available",
    requiresKey: true,
    runsInBrowser: false,
    supportsTextToImage: true,
    supportsImageInput: "model-dependent",
    supportsImageOutput: true,
    supportsImg2Img: "model-dependent",
    supportsInpainting: "model-dependent",
    supportsMasks: "model-dependent",
    supportsReferenceImage: "model-dependent",
    supportsSeed: "model-dependent",
    preservationLevel: "model-dependent"
  }
};

export function providerCanHandleTask(providerKey, taskType, needsStrictConsistency = false) {
  const p = PROVIDER_REGISTRY[providerKey];
  if (!p) return false;

  if (taskType === "generate") return !!p.supportsTextToImage;

  if (["edit", "img2img", "improve", "add_person", "modify_character"].includes(taskType)) {
    if (needsStrictConsistency && !p.supportsImageInput) return false;
    return !!p.supportsImg2Img || !!p.supportsReferenceImage;
  }

  if (["inpaint", "remove_object", "change_background"].includes(taskType)) {
    return !!p.supportsInpainting && !!p.supportsMasks;
  }

  if (taskType === "upscale") {
    return providerKey === "huggingface" || providerKey === "cloudflare";
  }

  return false;
}

export function getProviderOrder(taskType, needsStrictConsistency = false) {
  const preferred = ["huggingface", "cloudflare", "aiHorde", "together", "deepai", "pollinations"];
  return preferred.filter((key) => providerCanHandleTask(key, taskType, needsStrictConsistency));
}
