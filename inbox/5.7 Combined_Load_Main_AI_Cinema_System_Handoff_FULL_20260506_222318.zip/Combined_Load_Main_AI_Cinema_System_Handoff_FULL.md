# Combined Load Main + Load AI Cinema System Handoff

Prepared: 2026-05-06T22:23:18

This combined file merges:

1. The uploaded Load Main 5.6 README / next-session handoff.
2. The earlier Load AI Generator Master Build Plan ZIP.
3. The updated AI Chat Studio and movie/content production requirements.
4. The final implementation direction for building Load as an AI-assisted cinema/content production ecosystem.

---

# PART 1: LOAD MAIN 5.6 README / NEXT SESSION HANDOFF

Claude, please resume the Load Main project from the current session notes.
Before doing any work, read:
SESSION_NOTES_2026-05-06.md
Also follow the continuity rule in CLAUDE.md.
Do not skip this. The session notes and CLAUDE.md are the authority for project continuity.
============================================================
CURRENT CONFIRMED STATE
============================================================
Important correction:
The current confirmed Load Main build marker is v17g9, not v17g8.
Do not roll back to v17g8.
Current expected live markers:
1. Service worker:
https://dssorit.github.io/ancient-covenant-scrolls/load/sw.js
Expected:
var CACHE = 'load-v17g9';
2. Main index file:
https://dssorit.github.io/ancient-covenant-scrolls/load/index.html
Expected near the top of the file, right after the opening <body> tag:
<!-- LOAD_MAIN_BUILD: v17g9 -->
If GitHub Pages or CDN cache has not caught up yet, confirm what is actually live before patching.
============================================================
CURRENT ISSUE
============================================================
The handoff features were implemented, but the /load/ home page itself does not surface the key handoff buttons clearly enough for a casual audit.
Many of the tools live one or more taps deeper behind:
Workspace shortcut → Workspace Tools → category page → tool
That is too buried for verification.
I want the next patch to improve home-page discoverability by adding a direct visible row of handoff-feature shortcuts on the Load home page.
This is a discoverability patch, not a redesign.
============================================================
STRICT PATCH RULES
============================================================
Do not remove existing routes.
Do not consolidate or redesign the whole site.
Do not rename the core tools.
Do not ship a broad UI reorganization.
Do not change the working implementations of the tools.
Do not duplicate the tool logic.
Do not rebuild the whole site.
Do not reintroduce prohibited user-facing wording.
Patch only what is needed to make the handoff features directly visible from the /load/ home page.
Use existing tool pages and existing routes.
The purpose is audit visibility:
A person landing on /load/ should immediately see that these handoff tools exist without needing to know hidden URLs or nested menu paths.
============================================================
REQUIRED HOME-PAGE SHORTCUT ROW
============================================================
Add a clearly visible section on the /load/ home page titled:
Handoff Verification Tools
Add direct buttons or cards for the following tools:
1. Run All Tests
   Link to:
   Feature Verification Dashboard / feature-tests.html
2. Build Standalone PWA ZIP
   Link to:
   PWA Builder / pwa-builder.html
3. LoadStudio Package Validator
   Link to:
   loadstudio-validator.html
4. Rights & Safety Validator
   Link to:
   the relevant rights/safety validation tool or validator flow
5. Sandbox Preview
   Link to:
   the sandbox preview tool or imported-package preview flow
6. Export Receipt / Security Report Proof
   Link to:
   the builder or relevant report-output proof section where export-receipt.json and security-report.json are generated
The section should be visible enough that a casual audit of the home page can immediately see the handoff tools exist.
Recommended placement:
Near the existing Workspace or Developer/Diagnostics area, not hidden in Help.
Recommended copy tone:
Clear, plain-language, audit-friendly.
Example card descriptions:
Run All Tests
Open the Feature Verification Dashboard and run the Load Main verification checks.
Build Standalone PWA ZIP
Build a complete standalone PWA package with receipt and security report.
LoadStudio Package Validator
Inspect .loadstudio.zip and .cinepwa packages for required files, folders, rights, and safety status.
Rights & Safety Validator
Check rights metadata and safety blockers before publish-prep.
Sandbox Preview
Preview imported HTML/PWA content in the safer sandbox flow.
Export Receipt / Security Report Proof
Open the builder/report proof area that generates export-receipt.json and security-report.json.
============================================================
PICKUP STEPS IN EXACT ORDER
============================================================
0. Confirm live deployment status first.
Check:
https://dssorit.github.io/ancient-covenant-scrolls/load/sw.js
It should show:
var CACHE = 'load-v17g9';
Also confirm:
https://dssorit.github.io/ancient-covenant-scrolls/load/index.html
contains:
<!-- LOAD_MAIN_BUILD: v17g9 -->
If the live site still shows an older version, report that honestly before patching.
Do not proceed as if v17g9 is live unless you can confirm it or explain the cache/CDN lag clearly.
------------------------------------------------------------
1. Walk through the handoff features still awaiting user verification.
Verify or leave correctly labeled as READY FOR USER VERIFICATION:
- Run All Tests
- Build Standalone PWA ZIP
- export-receipt.json generation
- security-report.json generation
- safety scan blocking unsafe export
- LoadStudio validator
- Prepare-for-LoadPlay refusal when rights or safety blocks publish
- prohibited user-facing wording sweep
- optional Piper play() error capture
Important:
Do not mark iPad-only behavior VERIFIED unless it was actually tested on the user’s iPad or the user confirms it.
Use only the allowed status labels:
VERIFIED
READY FOR USER VERIFICATION
NOT DONE
Do not use vague wording such as “should work,” “likely,” “probably,” or “implemented” without proof.
------------------------------------------------------------
2. Patch home-page discoverability.
Add the direct Handoff Verification Tools row described above.
Requirements:
- Must be visible on the /load/ home page.
- Must be accessible without opening nested Workspace Tools.
- Must use existing tool pages and routes.
- Must not duplicate code logic.
- Must not remove existing deeper navigation.
- Must not change the working tool implementations.
- Must not reintroduce prohibited user-facing wording.
- Must preserve the existing cache/update architecture.
- Must keep internal dev references intact where needed.
- Must not alter the font implementation internals unless necessary.
Allowed internal developer references may remain if not displayed to users:
@font-face font-family names
CSS class names
data attribute values
font filenames
technical comments that are not user-facing
The rule is:
Do not display the prohibited wording in the user-facing interface.
------------------------------------------------------------
3. After patching, bump the build marker and cache version.
Use the next version:
v17g10
Update:
- sw.js cache name to:
load-v17g10
- index.html build marker to:
<!-- LOAD_MAIN_BUILD: v17g10 -->
Confirm that the service worker still deletes old load-* caches and does not keep an older HTML shell alive while online.
------------------------------------------------------------
4. Provide a final patch report.
Include:
- Exact files changed
- Exact files to upload or replace
- Confirmation that only necessary files were changed
- Confirmation that the new Handoff Verification Tools row is visible on /load/
- Confirmation that all shortcut links work
- Confirmation that no prohibited user-facing wording was reintroduced
- Confirmation that sw.js now uses load-v17g10
- Confirmation that index.html contains LOAD_MAIN_BUILD: v17g10
- Confirmation that the service worker cache-bust path still works
- Any rows still marked READY FOR USER VERIFICATION
- Any rows still marked NOT DONE
- Any risks or limitations
- Exact test commands used, such as grep, curl, or Node smoke tests where applicable
Do not mark the patch complete unless the direct shortcut row appears on /load/ and each button reaches the intended tool.
============================================================
DO NOT START THESE YET
============================================================
Do not start X-VIDEO-AI, X-DB, or X-SUBS until this home-page discoverability patch is complete and confirmed.
After this patch is complete, the next major spec order is:
1. X-VIDEO-AI
2. X-DB
3. X-SUBS
Recommended next session after this patch:
Start X-VIDEO-AI first, then database, then subscriptions.
============================================================
NEW MASTER BUILD ITEM TO ADD TO ROADMAP AFTER THIS PATCH
============================================================
Add this to the Load ecosystem roadmap, but do not start building it until the home-page discoverability patch is complete and confirmed.
NEW MASTER BUILD ITEM:
LOAD AI MODEL INDEPENDENCE SYSTEM
This is the strategic system for building Load’s own main AI intelligence layer so Load is not dependent on Glam AI, OpenAI, Gemini, or any single outside provider.
This must be split correctly:
Load Main gets:
X-AI-CORE: Load AI Core and Model Independence Layer
LoadStudio gets:
X-STUDIO-AI: Load Creation Engine for AI Production
Do not build the full creative AI studio inside Load Main.
Load Main should own the shared AI infrastructure, model routing, local/open-source model connectors, diagnostics, safety, rights, project memory, and fallback behavior.
LoadStudio should own the creative workflows that turn books, scripts, images, voices, and media into scene-based cinema projects.
============================================================
LOAD MAIN ROADMAP ITEM: X-AI-CORE
============================================================
Add to the Load Main roadmap:
X-AI-CORE: Load AI Core and Model Independence Layer
Purpose:
Create Load’s own AI infrastructure layer so Load can run independently of one external AI provider while still allowing optional open-source models, local models, and commercial provider fallbacks.
Load Main owns the engine room.
X-AI-CORE requirements:
1. Build Load AI Core as a shared AI intelligence layer.
2. Add provider/model routing independent of any single external API.
3. Support local-first mode with no API key.
4. Support open-source model connectors.
5. Support optional commercial/cloud providers only when enabled by the user.
6. Keep all optional cloud providers off by default.
7. Add model capability detection for:
   - text
   - image
   - video
   - audio
   - voice
   - embeddings
   - safety
   - document parsing
8. Add provider status labels:
   - Not configured
   - Ready
   - Failed
   - Rate limited
   - Unsupported request
   - Returned no file
9. Add fallback routing:
   - local model where available
   - open-source connector
   - optional cloud provider
   - prompt-only fallback
10. Add output proof rules:
   - never claim image generation unless file/blob/URL exists
   - never claim audio generation unless playable file/blob exists
   - never claim video generation unless playable file/blob/URL exists
   - never claim ZIP generation unless Blob passes ZIP header check
11. Add project-memory schema for:
   - scenes
   - characters
   - styles
   - voices
   - wardrobe
   - rights
   - continuity
   - prompts
   - outputs
12. Add rights metadata writer.
13. Add safety scanner integration.
14. Add diagnostic tests for every model connector.
15. Add model settings panel.
16. Add exportable AI diagnostic report.
17. Make local/open-source support the preferred strategic direction.
18. Do not hard-code API keys.
19. Do not mark a model connector READY without a real test response.
20. Do not claim generated output unless the output file/blob/URL exists.
21. Add connector architecture for future local engines, such as:
   - local LLM server
   - ComfyUI
   - Stable Diffusion workflows
   - Piper or Kokoro TTS
   - FFmpeg
   - image/video/audio model servers
22. Keep the Load AI Core reusable by LoadStudio and later LoadPlay.
23. Do not trap Load Main into one model, one provider, or one API key.
24. Add a prompt-only fallback so creators can still export structured prompts and scene data even when no generation model is available.
25. Add clear user-facing provider truth:
   Core Load can work local-first.
   Optional online providers only run when enabled.
   Local/open-source models may require separate installation or local server setup.
   Generated outputs are only confirmed when an actual file/blob/URL is returned.
============================================================
LOADSTUDIO ROADMAP ITEM: X-STUDIO-AI
============================================================
Add to the LoadStudio roadmap:
X-STUDIO-AI: Load Creation Engine for AI Production
Purpose:
Use Load Main’s X-AI-CORE to power creative production workflows inside LoadStudio.
LoadStudio owns the creative cockpit.
X-STUDIO-AI requirements:
1. Build Load Creation Engine inside LoadStudio.
2. Add AI Scene Builder.
3. Add Book-to-Cinema workflow.
4. Add Script-to-Shot workflow.
5. Add Character Bible generator.
6. Add Style Bible generator.
7. Add Voice Bible generator.
8. Add Wardrobe Continuity tracker.
9. Add Visual Prompt generator.
10. Add Negative Prompt generator.
11. Add Video Prompt generator.
12. Add Music/SFX prompt generator.
13. Add AI narration draft generator.
14. Add subtitle draft generator.
15. Add shot-list generator.
16. Add Character Consistency checker.
17. Add Scene Consistency checker.
18. Allow generated assets to attach to scenes.json.
19. Allow generated character data to attach to characters.json.
20. Allow generated rights data to attach to rights.json.
21. Export AI-built projects as:
   - .loadstudio.zip
   - .cinepwa.zip
22. Reopen and edit AI-built projects inside LoadStudio.
23. Use Load Main’s X-AI-CORE model router instead of locking LoadStudio to one provider.
24. Never make one outside provider a hard dependency.
25. Always allow prompt-only fallback if generation fails.
26. Store production intelligence in structured files, including:
   - scenes.json
   - characters.json
   - rights.json
   - credits.json
   - style-bible.json
   - voice-bible.json
   - wardrobe-bible.json
   - continuity-report.json
   - prompt-log.json
   - generation-report.json
27. Require output proof before claiming generation succeeded.
28. Preserve editable project structure.
29. Keep creator packages compatible with Load Main validation and LoadPlay publish-prep.
30. Connect this later to X-VIDEO-AI so AI video generation does not become a separate disconnected system.
============================================================
LOADPLAY AI SCOPE: LATER, NOT NOW
============================================================
Do not build this into LoadPlay first.
LoadPlay can later use AI for:
- moderation
- catalog tagging
- recommendation support
- captions
- thumbnail suggestions
- upload review
- content safety review
- rights metadata review
But the AI creation engine belongs in LoadStudio, powered by Load Main’s shared X-AI-CORE.
LoadPlay should not become the AI creation center.
============================================================
RECOMMENDED DEVELOPMENT ORDER
============================================================
Current immediate order:
1. Finish Load Main home-page discoverability patch.
2. Bump Load Main to v17g10.
3. Confirm shortcut row on /load/.
4. Confirm all links work.
5. Confirm no prohibited wording was reintroduced.
6. Close stale pending rows.
7. Keep only genuinely open rows.
Then roadmap order:
1. X-VIDEO-AI
2. X-AI-CORE roadmap scoping
3. X-STUDIO-AI roadmap scoping
4. X-DB
5. X-SUBS
Important:
X-AI-CORE and X-STUDIO-AI should be added to the roadmap now, but do not start coding them until the current Load Main discoverability patch is complete and confirmed.
============================================================
FINAL CAUTION
============================================================
Do not claim the home page is complete unless:
1. The direct Handoff Verification Tools row appears on /load/.
2. Each shortcut reaches the intended tool.
3. sw.js uses load-v17g10.
4. index.html contains LOAD_MAIN_BUILD: v17g10.
5. No prohibited user-facing wording was reintroduced.
6. The final report clearly separates VERIFIED, READY FOR USER VERIFICATION, and NOT DONE.
7. No iPad-only behavior is marked VERIFIED unless the user has tested it or confirmed it.
Do not drift into X-VIDEO-AI, X-DB, X-SUBS, X-AI-CORE, or X-STUDIO-AI until this patch is finished.

---

# PART 2: PREVIOUS LOAD AI GENERATOR MASTER BUILD PLAN CONTENT

## Files found in uploaded AI generator ZIP

- Load_AI_Generator_Master_Build_Plan.md
- Load_AI_Generator_Master_Build_Plan.txt


## Source file from uploaded ZIP: Load_AI_Generator_Master_Build_Plan.md

# Load AI Generator Master Build Plan

Prepared for Claude handoff  
Purpose: Add the Load AI Model Independence System to the Load ecosystem roadmap and provide a complete future build specification for X-AI-CORE and X-STUDIO-AI.

Important usage note:
Do not give this to Claude until the Load Main v17g10 home-page discoverability patch is complete and confirmed.

---

# 1. Core Concept

The AI generator should not be treated as a small chat feature. It should become the Load-owned creative intelligence system that can power Load Main, LoadStudio, and later LoadPlay without depending on one outside provider.

Correct structure:

```text
Load Main = AI core infrastructure
LoadStudio = AI creative production engine
LoadPlay = AI catalog/moderation support later
```

Strategic goal:

```text
Build Load’s own model-independent AI creation system that can use local models, open-source models, optional cloud providers, and future Load-hosted models without being locked to one API key or one company.
```

---

# 2. Product Name

Recommended system name:

```text
Load Creation Engine
```

Technical layer names:

```text
X-AI-CORE = Load Main shared AI infrastructure
X-STUDIO-AI = LoadStudio creative production system
```

Plain-language product description:

```text
Load Creation Engine turns books, scripts, documents, images, audio, and creator notes into structured scene projects, character bibles, visual prompts, voice directions, video prompts, editable assets, and LoadStudio cinema packages.
```

---

# 3. Placement Across Load Ecosystem

## A. Load Main Placement

Load Main should contain the infrastructure layer.

Load Main owns:

```text
AI Core Settings
Model Connector Manager
Provider Router
Local Model Connector
Open-Source Model Connector
Optional Cloud Provider Connector
Project Memory
Rights Metadata Writer
Safety Scanner Integration
Output Proof Rules
AI Diagnostic Report
Model Status Tests
Prompt-only Fallback
```

Load Main should answer:

```text
Which model is available?
Is this model local, open-source, cloud, or prompt-only?
What can this model generate?
Did the model return a real file/blob/URL?
Can the output be exported safely?
Are rights metadata and safety reports attached?
Can this project be routed to LoadStudio or LoadPlay?
```

Load Main should not do:

```text
Full scene editing
Full cinematic timeline editing
Advanced character/wardrobe production
Full video production workflow
Creator channel publishing
Subscription logic
```

---

## B. LoadStudio Placement

LoadStudio should contain the creative production layer.

LoadStudio owns:

```text
AI Scene Builder
Book-to-Cinema Workflow
Script-to-Shot Workflow
Character Bible Generator
Style Bible Generator
Voice Bible Generator
Wardrobe Continuity Tracker
Prompt Studio
Image Prompt Generator
Video Prompt Generator
Music/SFX Prompt Generator
Scene Consistency Checker
Character Consistency Checker
Generation Queue
Output Review
Export to .loadstudio.zip / .cinepwa.zip
```

LoadStudio should answer:

```text
How do I turn this book into scenes?
How do I keep the same character consistent?
How do I create a shot list?
How do I generate image/video/voice prompts?
How do I attach outputs to scenes.json?
How do I export a playable/editable LoadStudio package?
```

---

## C. LoadPlay Placement

LoadPlay should not be the AI creation center.

Later, LoadPlay can use AI for:

```text
Catalog tagging
Content moderation
Caption assistance
Thumbnail suggestions
Upload review
Search enrichment
Recommendation support
Rights metadata review
```

LoadPlay should receive validated content. It should not become the main AI studio.

---

# 4. Build Order

Do not build this before the current Load Main discoverability patch is complete.

Recommended order:

```text
1. Complete Load Main v17g10 discoverability patch
2. Confirm Load Main user verification items
3. Add X-AI-CORE roadmap files and UI placeholders
4. Build X-AI-CORE in Load Main
5. Build X-STUDIO-AI in LoadStudio
6. Connect X-STUDIO-AI to X-VIDEO-AI
7. Then continue X-DB
8. Then X-SUBS
```

Do not let Claude start coding this while Load Main v17g10 still needs verification.

---

# 5. X-AI-CORE Build Specification for Load Main

## Purpose

X-AI-CORE is the shared AI infrastructure layer. It makes Load independent of any single AI company, while allowing local, open-source, optional cloud, and future Load-hosted models.

## Required Screens in Load Main

Add a new top-level tool area:

```text
Load AI Core
```

Inside it:

```text
AI Core Settings
Model Connectors
Provider Status
Prompt-only Fallback
Project Memory
Rights & Safety
AI Diagnostics
Export AI Report
```

## Required Files/Modules

Use the existing project structure if different, but conceptually create:

```text
/load/ai-core/index.html
/load/ai-core/ai-core.js
/load/ai-core/provider-router.js
/load/ai-core/model-registry.js
/load/ai-core/model-capabilities.js
/load/ai-core/local-model-connector.js
/load/ai-core/open-source-connector.js
/load/ai-core/cloud-provider-connector.js
/load/ai-core/prompt-only-connector.js
/load/ai-core/project-memory.js
/load/ai-core/output-proof.js
/load/ai-core/rights-writer.js
/load/ai-core/safety-ai-bridge.js
/load/ai-core/ai-diagnostics.js
/load/ai-core/ai-report-exporter.js
/load/ai-core/model-settings.html
/load/ai-core/model-settings.js
```

If Claude cannot use folders, then use:

```text
load-ai-core.html
load-ai-core.js
provider-router.js
model-registry.js
model-capabilities.js
project-memory.js
output-proof.js
rights-writer.js
ai-diagnostics.js
```

---

# 6. Model Independence Architecture

## Required Provider Types

X-AI-CORE must support these connector types:

```text
local
open-source
cloud-optional
load-hosted-future
prompt-only
```

## Provider Status Values

Every connector must report one of:

```text
Not configured
Ready
Failed
Rate limited
Unsupported request
Returned no file
Offline
Local server unavailable
Needs user setup
```

## Capability Detection

Each model connector must declare capabilities:

```json
{
  "providerId": "local-comfyui",
  "providerName": "Local ComfyUI",
  "providerType": "local",
  "enabled": false,
  "requiresApiKey": false,
  "requiresLocalServer": true,
  "endpoint": "http://localhost:8188",
  "capabilities": {
    "text": false,
    "image": true,
    "video": false,
    "audio": false,
    "voice": false,
    "embeddings": false,
    "safety": false,
    "documentParsing": false
  },
  "status": "Needs user setup"
}
```

## Fallback Routing Order

Default routing order:

```text
1. Local model where available
2. Open-source connector
3. User-enabled optional cloud provider
4. Prompt-only fallback
```

Never make one outside provider mandatory.

---

# 7. Output Proof Rules

This must be non-negotiable.

```text
Never claim image generation succeeded unless a real file/blob/URL exists.
Never claim audio generation succeeded unless a playable file/blob exists.
Never claim video generation succeeded unless a playable file/blob/URL exists.
Never claim text generation succeeded unless non-empty text exists.
Never claim ZIP generation succeeded unless Blob passes ZIP header check.
Never claim model is ready unless a real test response succeeds.
```

## Output Proof Schema

```json
{
  "outputId": "output_001",
  "requestId": "request_001",
  "providerId": "local-comfyui",
  "type": "image",
  "status": "VERIFIED_OUTPUT",
  "fileUrl": "assets/images/scene_001.png",
  "blobVerified": true,
  "mimeType": "image/png",
  "sizeBytes": 345122,
  "createdAt": "2026-05-06T00:00:00.000Z",
  "proof": {
    "hasFile": true,
    "hasBlob": true,
    "hasUrl": false,
    "playable": null,
    "nonEmptyText": null
  }
}
```

---

# 8. Project Memory System

Load should have structured memory per project, not just chat history.

## Required Project Memory Files

```text
ai-project.json
model-routing.json
scene-plan.json
characters.json
style-bible.json
voice-bible.json
wardrobe-bible.json
prompt-log.json
generation-report.json
rights.json
continuity-report.json
asset-declarations.json
```

## ai-project.json

```json
{
  "projectId": "load_project_001",
  "projectType": "load.ai.creation",
  "title": "Untitled AI Creation Project",
  "sourceType": "book",
  "sourceFiles": [],
  "createdAt": "2026-05-06T00:00:00.000Z",
  "updatedAt": "2026-05-06T00:00:00.000Z",
  "status": "draft",
  "targetExport": [
    ".loadstudio.zip",
    ".cinepwa.zip"
  ]
}
```

## model-routing.json

```json
{
  "routingMode": "local-first",
  "fallbackEnabled": true,
  "providers": [],
  "lastSuccessfulProvider": null,
  "promptOnlyFallback": true
}
```

## prompt-log.json

```json
{
  "prompts": [
    {
      "promptId": "prompt_001",
      "sceneId": "scene_001",
      "type": "image",
      "providerId": "prompt-only",
      "prompt": "cinematic opening scene...",
      "negativePrompt": "distorted face, extra limbs, unreadable text",
      "createdAt": "2026-05-06T00:00:00.000Z",
      "status": "drafted"
    }
  ]
}
```

---

# 9. Rights and Safety Integration

Every generated output must carry rights metadata.

## Required Rights Fields

```json
{
  "owner": "Creator name or company",
  "license": "user-owned",
  "sourceMaterial": "Original manuscript",
  "assetDeclarations": [
    {
      "asset": "assets/images/scene_001.png",
      "status": "user-generated",
      "provider": "local-comfyui",
      "model": "model-name",
      "promptId": "prompt_001",
      "commercialUseStatus": "needs-review"
    }
  ],
  "notes": "Creator confirms rights to upload and distribute."
}
```

## Rights Statuses

```text
user-owned
public-domain
licensed
platform-original
user-generated
user-recorded
third-party-licensed
unknown
needs-review
```

## Safety Checks

The AI generator must check for:

```text
missing rights metadata
unknown asset rights
unsafe prompts
unsafe generated outputs
hard-coded provider API keys
hidden .env files
external URLs
credential capture forms
unverified model outputs
blocked publish status
```

---

# 10. X-STUDIO-AI Build Specification for LoadStudio

## Purpose

X-STUDIO-AI is the creative production engine inside LoadStudio. It uses Load Main’s X-AI-CORE to produce structured scenes, prompts, characters, voices, styles, and exportable packages.

## Required Screens in LoadStudio

```text
Load Creation Engine
AI Scene Builder
Book-to-Cinema
Script-to-Shot
Character Bible
Style Bible
Voice Bible
Wardrobe Continuity
Prompt Studio
Generation Queue
Output Review
Continuity Check
Export to LoadStudio Package
```

## Required Files/Modules

```text
/loadstudio/ai/creation-engine.html
/loadstudio/ai/creation-engine.js
/loadstudio/ai/book-to-cinema.js
/loadstudio/ai/script-to-shot.js
/loadstudio/ai/scene-builder.js
/loadstudio/ai/character-bible.js
/loadstudio/ai/style-bible.js
/loadstudio/ai/voice-bible.js
/loadstudio/ai/wardrobe-bible.js
/loadstudio/ai/prompt-studio.js
/loadstudio/ai/generation-queue.js
/loadstudio/ai/output-review.js
/loadstudio/ai/continuity-checker.js
/loadstudio/ai/export-loadstudio-package.js
```

---

# 11. LoadStudio AI Workflows

## Workflow 1: Book to Cinema

Steps:

```text
1. Import book, PDF, DOCX, EPUB, TXT, Markdown, or existing Load book project.
2. Extract title, chapters, sections, characters, locations, and tone.
3. Split source into scene cards.
4. Generate scene summaries.
5. Generate narration drafts.
6. Generate character bible entries.
7. Generate visual style bible.
8. Generate image prompts and negative prompts.
9. Generate video prompts.
10. Generate voice directions.
11. Generate music/SFX notes.
12. Save all data into structured JSON.
13. Allow user review and edit.
14. Attach generated or imported assets.
15. Export as .loadstudio.zip or .cinepwa.zip.
```

## Workflow 2: Script to Shot

Steps:

```text
1. Import script or paste script.
2. Detect scenes.
3. Detect dialogue.
4. Detect characters.
5. Detect locations.
6. Generate shot list.
7. Generate camera directions.
8. Generate prompt package per shot.
9. Generate scene timing.
10. Export scene cards and prompts.
```

## Workflow 3: Character Bible

Required fields:

```json
{
  "characterId": "character_001",
  "name": "Character Name",
  "ageRange": "adult",
  "appearance": "locked appearance",
  "hair": "locked hair",
  "skinTone": "locked skin tone",
  "bodyType": "locked body type",
  "clothing": "locked clothing",
  "era": "locked era",
  "voiceStyle": "voice direction",
  "personality": "brief traits",
  "referenceImages": [],
  "consistencyRules": "Do not change face, age, wardrobe, or era.",
  "negativeTraitsToAvoid": "do not modernize wardrobe, do not alter identity"
}
```

## Workflow 4: Prompt Studio

Prompt types:

```text
image prompt
negative prompt
video prompt
voice prompt
music prompt
SFX prompt
subtitle prompt
narration prompt
continuity check prompt
rights metadata prompt
```

## Workflow 5: Continuity Check

Check:

```text
character face consistency
wardrobe consistency
era consistency
location continuity
scene order
voice consistency
visual style drift
missing assets
missing rights metadata
missing prompts
unverified outputs
```

---

# 12. Export Requirements

X-STUDIO-AI must export AI-built projects into the existing package structure.

## Required .loadstudio.zip / .cinepwa.zip Files

```text
index.html
manifest.json
service-worker.js
project.json
scenes.json
characters.json
rights.json
credits.json
styles.css
player.js
editor.js
assets/images/
assets/audio/
assets/music/
assets/sfx/
assets/subtitles/
assets/icons/
```

## Additional AI Files

```text
style-bible.json
voice-bible.json
wardrobe-bible.json
prompt-log.json
generation-report.json
continuity-report.json
model-routing.json
asset-declarations.json
```

These extra files should not break the validator. They should enhance the package.

---

# 13. UI Principle

The AI generator must not feel like a generic chatbox.

It should feel like a production control system.

Use this structure:

```text
Input
Plan
Generate
Review
Attach
Validate
Export
```

## Main UI Sections

```text
1. Source Material
2. Project Plan
3. Characters
4. Scenes
5. Prompts
6. Generation Queue
7. Outputs
8. Continuity
9. Rights & Safety
10. Export
```

---

# 14. Prompt-only Fallback

This is important.

Even if no model is connected, Load should still generate and export:

```text
scene cards
character bibles
style bibles
voice bibles
image prompts
video prompts
music/SFX prompts
negative prompts
rights metadata drafts
continuity reports
```

This means the system remains useful without API keys.

Label this mode:

```text
Prompt-only Mode
```

User-facing explanation:

```text
No generation model is connected. Load can still build structured scene plans, prompts, bibles, and export-ready project files for use with your preferred model.
```

---

# 15. Build Acceptance Criteria

The AI generator is not complete unless:

```text
1. Load Main has X-AI-CORE settings screen.
2. Model connector registry exists.
3. Capability detection exists.
4. Provider statuses exist.
5. Prompt-only fallback works.
6. Local/open-source connector placeholders exist.
7. Optional cloud providers are off by default.
8. No API keys are hard-coded.
9. Output proof rules exist.
10. Rights metadata writer exists.
11. Safety integration exists.
12. AI diagnostic report exports.
13. LoadStudio can open Load Creation Engine.
14. LoadStudio can generate scene cards from source text.
15. LoadStudio can generate character bible entries.
16. LoadStudio can generate style bible.
17. LoadStudio can generate image and video prompts.
18. LoadStudio can create prompt-log.json.
19. LoadStudio can create generation-report.json.
20. LoadStudio can attach outputs to scenes.
21. LoadStudio can export .loadstudio.zip / .cinepwa.zip.
22. Exported packages pass Load Main validator.
23. No success message appears without verified output.
24. Failed generation returns prompt and reason.
25. User can continue in prompt-only mode.
```

---

# 16. Claude-ready Full Prompt

Give Claude this after the Load Main v17g10 patch is complete.

```text
Claude, start the next major roadmap item: Load AI Model Independence System.

Before coding, read:
- SESSION_NOTES_2026-05-06.md
- CLAUDE.md
- current Load Main build notes
- current LoadStudio build notes

Do not start this if the Load Main v17g10 home-page discoverability patch is not complete and confirmed.

Goal:
Build the Load AI Model Independence System so Load has its own core AI infrastructure independent of any single provider, while allowing local models, open-source models, optional cloud providers, and future Load-hosted models.

This must be split into two build areas:

1. Load Main:
X-AI-CORE: Load AI Core and Model Independence Layer

2. LoadStudio:
X-STUDIO-AI: Load Creation Engine for AI Production

Do not build the full creative AI studio inside Load Main.
Do not build the AI creation engine inside LoadPlay.
Do not make any outside provider a hard dependency.
Do not hard-code API keys.
Do not mark generated output complete unless a real file/blob/URL exists.
Do not mark model connector READY unless a real test succeeds.

============================================================
PART 1: LOAD MAIN X-AI-CORE
============================================================

Build Load Main’s shared AI infrastructure layer.

Required Load Main screens:
- Load AI Core
- AI Core Settings
- Model Connectors
- Provider Status
- Prompt-only Fallback
- Project Memory
- Rights & Safety
- AI Diagnostics
- Export AI Report

Required modules:
- ai-core.js
- provider-router.js
- model-registry.js
- model-capabilities.js
- local-model-connector.js
- open-source-connector.js
- cloud-provider-connector.js
- prompt-only-connector.js
- project-memory.js
- output-proof.js
- rights-writer.js
- safety-ai-bridge.js
- ai-diagnostics.js
- ai-report-exporter.js

If the file structure differs, adapt to the existing project but keep these modules logically separated.

X-AI-CORE requirements:

1. Add provider/model routing independent of any single external API.
2. Support provider types: local, open-source, cloud-optional, load-hosted-future, prompt-only.
3. Support model capability detection for text, image, video, audio, voice, embeddings, safety, and document parsing.
4. Add provider statuses: Not configured, Ready, Failed, Rate limited, Unsupported request, Returned no file, Offline, Local server unavailable, Needs user setup.
5. Add fallback routing: local model where available, open-source connector, optional cloud provider, prompt-only fallback.
6. Keep all optional cloud providers off by default.
7. Add connector placeholders for local LLM server, ComfyUI, Stable Diffusion workflows, Piper, Kokoro TTS, FFmpeg, and future Load-hosted model server.
8. Add output proof rules.
9. Add project memory files.
10. Add rights metadata writer.
11. Add safety scanner integration.
12. Add AI diagnostic tests for each connector.
13. Add exportable AI diagnostic report.
14. Add prompt-only mode.
15. Add user-facing provider truth.

============================================================
PART 2: LOADSTUDIO X-STUDIO-AI
============================================================

Build LoadStudio’s creative AI production engine using Load Main’s X-AI-CORE.

Required LoadStudio screens:
- Load Creation Engine
- AI Scene Builder
- Book-to-Cinema
- Script-to-Shot
- Character Bible
- Style Bible
- Voice Bible
- Wardrobe Continuity
- Prompt Studio
- Generation Queue
- Output Review
- Continuity Check
- Export to LoadStudio Package

Required modules:
- creation-engine.js
- book-to-cinema.js
- script-to-shot.js
- scene-builder.js
- character-bible.js
- style-bible.js
- voice-bible.js
- wardrobe-bible.js
- prompt-studio.js
- generation-queue.js
- output-review.js
- continuity-checker.js
- export-loadstudio-package.js

X-STUDIO-AI requirements:
1. Add AI Scene Builder.
2. Add Book-to-Cinema workflow.
3. Add Script-to-Shot workflow.
4. Add Character Bible generator.
5. Add Style Bible generator.
6. Add Voice Bible generator.
7. Add Wardrobe Continuity tracker.
8. Add Prompt Studio.
9. Add Generation Queue.
10. Add Output Review.
11. Add Character Consistency checker.
12. Add Scene Consistency checker.
13. Add Continuity Check.
14. Attach generated assets to scenes.json.
15. Attach generated character data to characters.json.
16. Attach rights data to rights.json.
17. Create style-bible.json, voice-bible.json, wardrobe-bible.json, prompt-log.json, generation-report.json, continuity-report.json, model-routing.json, and asset-declarations.json.
18. Export AI-built projects as .loadstudio.zip and .cinepwa.zip.
19. Reopen and edit AI-built projects inside LoadStudio.
20. Use Load Main’s X-AI-CORE router.
21. Always allow prompt-only fallback if generation fails.
22. Failed generation must return failure reason, provider attempted, prompt used, and next recommended action.
23. No generated image/audio/video success message unless real file/blob/URL exists.

============================================================
PART 3: EXPORT PACKAGE REQUIREMENTS
============================================================

Exported AI-built projects must include the existing LoadStudio package structure plus AI files.

Exported packages must pass the existing Load Main LoadStudio validator.

============================================================
PART 4: UI PRINCIPLE
============================================================

Do not make this feel like a generic chatbox.

The UI should follow this production pipeline:

Input → Plan → Generate → Review → Attach → Validate → Export

Main sections:
1. Source Material
2. Project Plan
3. Characters
4. Scenes
5. Prompts
6. Generation Queue
7. Outputs
8. Continuity
9. Rights & Safety
10. Export

============================================================
PART 5: ACCEPTANCE CRITERIA
============================================================

The AI system is not complete unless all acceptance criteria in the master plan are met.

============================================================
PART 6: FINAL REPORT REQUIRED
============================================================

When complete, provide:
1. Exact files changed.
2. Exact files added.
3. Exact files to upload.
4. Confirmation that only necessary files were changed.
5. New screens added.
6. New modules added.
7. Connector registry status.
8. Provider routing behavior.
9. Prompt-only fallback proof.
10. Output proof rules proof.
11. Rights metadata proof.
12. Safety integration proof.
13. LoadStudio workflow proof.
14. Export package proof.
15. Validator pass/fail results.
16. Rows that are VERIFIED.
17. Rows that are READY FOR USER VERIFICATION.
18. Rows that are NOT DONE.
19. Known limitations.
20. Next recommended build step.

Do not mark anything complete without a visible test or code-level proof.
```

---

# 17. Final Recommendation

Do not give this to Claude as part of the small v17g10 patch. It is too large and will cause drift.

Use it after:

```text
Load Main v17g10 home-page handoff shortcut row is complete.
```

Then this becomes the next major roadmap build.



## Source file from uploaded ZIP: Load_AI_Generator_Master_Build_Plan.txt

# Load AI Generator Master Build Plan

Prepared for Claude handoff  
Purpose: Add the Load AI Model Independence System to the Load ecosystem roadmap and provide a complete future build specification for X-AI-CORE and X-STUDIO-AI.

Important usage note:
Do not give this to Claude until the Load Main v17g10 home-page discoverability patch is complete and confirmed.

---

# 1. Core Concept

The AI generator should not be treated as a small chat feature. It should become the Load-owned creative intelligence system that can power Load Main, LoadStudio, and later LoadPlay without depending on one outside provider.

Correct structure:

```text
Load Main = AI core infrastructure
LoadStudio = AI creative production engine
LoadPlay = AI catalog/moderation support later
```

Strategic goal:

```text
Build Load’s own model-independent AI creation system that can use local models, open-source models, optional cloud providers, and future Load-hosted models without being locked to one API key or one company.
```

---

# 2. Product Name

Recommended system name:

```text
Load Creation Engine
```

Technical layer names:

```text
X-AI-CORE = Load Main shared AI infrastructure
X-STUDIO-AI = LoadStudio creative production system
```

Plain-language product description:

```text
Load Creation Engine turns books, scripts, documents, images, audio, and creator notes into structured scene projects, character bibles, visual prompts, voice directions, video prompts, editable assets, and LoadStudio cinema packages.
```

---

# 3. Placement Across Load Ecosystem

## A. Load Main Placement

Load Main should contain the infrastructure layer.

Load Main owns:

```text
AI Core Settings
Model Connector Manager
Provider Router
Local Model Connector
Open-Source Model Connector
Optional Cloud Provider Connector
Project Memory
Rights Metadata Writer
Safety Scanner Integration
Output Proof Rules
AI Diagnostic Report
Model Status Tests
Prompt-only Fallback
```

Load Main should answer:

```text
Which model is available?
Is this model local, open-source, cloud, or prompt-only?
What can this model generate?
Did the model return a real file/blob/URL?
Can the output be exported safely?
Are rights metadata and safety reports attached?
Can this project be routed to LoadStudio or LoadPlay?
```

Load Main should not do:

```text
Full scene editing
Full cinematic timeline editing
Advanced character/wardrobe production
Full video production workflow
Creator channel publishing
Subscription logic
```

---

## B. LoadStudio Placement

LoadStudio should contain the creative production layer.

LoadStudio owns:

```text
AI Scene Builder
Book-to-Cinema Workflow
Script-to-Shot Workflow
Character Bible Generator
Style Bible Generator
Voice Bible Generator
Wardrobe Continuity Tracker
Prompt Studio
Image Prompt Generator
Video Prompt Generator
Music/SFX Prompt Generator
Scene Consistency Checker
Character Consistency Checker
Generation Queue
Output Review
Export to .loadstudio.zip / .cinepwa.zip
```

LoadStudio should answer:

```text
How do I turn this book into scenes?
How do I keep the same character consistent?
How do I create a shot list?
How do I generate image/video/voice prompts?
How do I attach outputs to scenes.json?
How do I export a playable/editable LoadStudio package?
```

---

## C. LoadPlay Placement

LoadPlay should not be the AI creation center.

Later, LoadPlay can use AI for:

```text
Catalog tagging
Content moderation
Caption assistance
Thumbnail suggestions
Upload review
Search enrichment
Recommendation support
Rights metadata review
```

LoadPlay should receive validated content. It should not become the main AI studio.

---

# 4. Build Order

Do not build this before the current Load Main discoverability patch is complete.

Recommended order:

```text
1. Complete Load Main v17g10 discoverability patch
2. Confirm Load Main user verification items
3. Add X-AI-CORE roadmap files and UI placeholders
4. Build X-AI-CORE in Load Main
5. Build X-STUDIO-AI in LoadStudio
6. Connect X-STUDIO-AI to X-VIDEO-AI
7. Then continue X-DB
8. Then X-SUBS
```

Do not let Claude start coding this while Load Main v17g10 still needs verification.

---

# 5. X-AI-CORE Build Specification for Load Main

## Purpose

X-AI-CORE is the shared AI infrastructure layer. It makes Load independent of any single AI company, while allowing local, open-source, optional cloud, and future Load-hosted models.

## Required Screens in Load Main

Add a new top-level tool area:

```text
Load AI Core
```

Inside it:

```text
AI Core Settings
Model Connectors
Provider Status
Prompt-only Fallback
Project Memory
Rights & Safety
AI Diagnostics
Export AI Report
```

## Required Files/Modules

Use the existing project structure if different, but conceptually create:

```text
/load/ai-core/index.html
/load/ai-core/ai-core.js
/load/ai-core/provider-router.js
/load/ai-core/model-registry.js
/load/ai-core/model-capabilities.js
/load/ai-core/local-model-connector.js
/load/ai-core/open-source-connector.js
/load/ai-core/cloud-provider-connector.js
/load/ai-core/prompt-only-connector.js
/load/ai-core/project-memory.js
/load/ai-core/output-proof.js
/load/ai-core/rights-writer.js
/load/ai-core/safety-ai-bridge.js
/load/ai-core/ai-diagnostics.js
/load/ai-core/ai-report-exporter.js
/load/ai-core/model-settings.html
/load/ai-core/model-settings.js
```

If Claude cannot use folders, then use:

```text
load-ai-core.html
load-ai-core.js
provider-router.js
model-registry.js
model-capabilities.js
project-memory.js
output-proof.js
rights-writer.js
ai-diagnostics.js
```

---

# 6. Model Independence Architecture

## Required Provider Types

X-AI-CORE must support these connector types:

```text
local
open-source
cloud-optional
load-hosted-future
prompt-only
```

## Provider Status Values

Every connector must report one of:

```text
Not configured
Ready
Failed
Rate limited
Unsupported request
Returned no file
Offline
Local server unavailable
Needs user setup
```

## Capability Detection

Each model connector must declare capabilities:

```json
{
  "providerId": "local-comfyui",
  "providerName": "Local ComfyUI",
  "providerType": "local",
  "enabled": false,
  "requiresApiKey": false,
  "requiresLocalServer": true,
  "endpoint": "http://localhost:8188",
  "capabilities": {
    "text": false,
    "image": true,
    "video": false,
    "audio": false,
    "voice": false,
    "embeddings": false,
    "safety": false,
    "documentParsing": false
  },
  "status": "Needs user setup"
}
```

## Fallback Routing Order

Default routing order:

```text
1. Local model where available
2. Open-source connector
3. User-enabled optional cloud provider
4. Prompt-only fallback
```

Never make one outside provider mandatory.

---

# 7. Output Proof Rules

This must be non-negotiable.

```text
Never claim image generation succeeded unless a real file/blob/URL exists.
Never claim audio generation succeeded unless a playable file/blob exists.
Never claim video generation succeeded unless a playable file/blob/URL exists.
Never claim text generation succeeded unless non-empty text exists.
Never claim ZIP generation succeeded unless Blob passes ZIP header check.
Never claim model is ready unless a real test response succeeds.
```

## Output Proof Schema

```json
{
  "outputId": "output_001",
  "requestId": "request_001",
  "providerId": "local-comfyui",
  "type": "image",
  "status": "VERIFIED_OUTPUT",
  "fileUrl": "assets/images/scene_001.png",
  "blobVerified": true,
  "mimeType": "image/png",
  "sizeBytes": 345122,
  "createdAt": "2026-05-06T00:00:00.000Z",
  "proof": {
    "hasFile": true,
    "hasBlob": true,
    "hasUrl": false,
    "playable": null,
    "nonEmptyText": null
  }
}
```

---

# 8. Project Memory System

Load should have structured memory per project, not just chat history.

## Required Project Memory Files

```text
ai-project.json
model-routing.json
scene-plan.json
characters.json
style-bible.json
voice-bible.json
wardrobe-bible.json
prompt-log.json
generation-report.json
rights.json
continuity-report.json
asset-declarations.json
```

## ai-project.json

```json
{
  "projectId": "load_project_001",
  "projectType": "load.ai.creation",
  "title": "Untitled AI Creation Project",
  "sourceType": "book",
  "sourceFiles": [],
  "createdAt": "2026-05-06T00:00:00.000Z",
  "updatedAt": "2026-05-06T00:00:00.000Z",
  "status": "draft",
  "targetExport": [
    ".loadstudio.zip",
    ".cinepwa.zip"
  ]
}
```

## model-routing.json

```json
{
  "routingMode": "local-first",
  "fallbackEnabled": true,
  "providers": [],
  "lastSuccessfulProvider": null,
  "promptOnlyFallback": true
}
```

## prompt-log.json

```json
{
  "prompts": [
    {
      "promptId": "prompt_001",
      "sceneId": "scene_001",
      "type": "image",
      "providerId": "prompt-only",
      "prompt": "cinematic opening scene...",
      "negativePrompt": "distorted face, extra limbs, unreadable text",
      "createdAt": "2026-05-06T00:00:00.000Z",
      "status": "drafted"
    }
  ]
}
```

---

# 9. Rights and Safety Integration

Every generated output must carry rights metadata.

## Required Rights Fields

```json
{
  "owner": "Creator name or company",
  "license": "user-owned",
  "sourceMaterial": "Original manuscript",
  "assetDeclarations": [
    {
      "asset": "assets/images/scene_001.png",
      "status": "user-generated",
      "provider": "local-comfyui",
      "model": "model-name",
      "promptId": "prompt_001",
      "commercialUseStatus": "needs-review"
    }
  ],
  "notes": "Creator confirms rights to upload and distribute."
}
```

## Rights Statuses

```text
user-owned
public-domain
licensed
platform-original
user-generated
user-recorded
third-party-licensed
unknown
needs-review
```

## Safety Checks

The AI generator must check for:

```text
missing rights metadata
unknown asset rights
unsafe prompts
unsafe generated outputs
hard-coded provider API keys
hidden .env files
external URLs
credential capture forms
unverified model outputs
blocked publish status
```

---

# 10. X-STUDIO-AI Build Specification for LoadStudio

## Purpose

X-STUDIO-AI is the creative production engine inside LoadStudio. It uses Load Main’s X-AI-CORE to produce structured scenes, prompts, characters, voices, styles, and exportable packages.

## Required Screens in LoadStudio

```text
Load Creation Engine
AI Scene Builder
Book-to-Cinema
Script-to-Shot
Character Bible
Style Bible
Voice Bible
Wardrobe Continuity
Prompt Studio
Generation Queue
Output Review
Continuity Check
Export to LoadStudio Package
```

## Required Files/Modules

```text
/loadstudio/ai/creation-engine.html
/loadstudio/ai/creation-engine.js
/loadstudio/ai/book-to-cinema.js
/loadstudio/ai/script-to-shot.js
/loadstudio/ai/scene-builder.js
/loadstudio/ai/character-bible.js
/loadstudio/ai/style-bible.js
/loadstudio/ai/voice-bible.js
/loadstudio/ai/wardrobe-bible.js
/loadstudio/ai/prompt-studio.js
/loadstudio/ai/generation-queue.js
/loadstudio/ai/output-review.js
/loadstudio/ai/continuity-checker.js
/loadstudio/ai/export-loadstudio-package.js
```

---

# 11. LoadStudio AI Workflows

## Workflow 1: Book to Cinema

Steps:

```text
1. Import book, PDF, DOCX, EPUB, TXT, Markdown, or existing Load book project.
2. Extract title, chapters, sections, characters, locations, and tone.
3. Split source into scene cards.
4. Generate scene summaries.
5. Generate narration drafts.
6. Generate character bible entries.
7. Generate visual style bible.
8. Generate image prompts and negative prompts.
9. Generate video prompts.
10. Generate voice directions.
11. Generate music/SFX notes.
12. Save all data into structured JSON.
13. Allow user review and edit.
14. Attach generated or imported assets.
15. Export as .loadstudio.zip or .cinepwa.zip.
```

## Workflow 2: Script to Shot

Steps:

```text
1. Import script or paste script.
2. Detect scenes.
3. Detect dialogue.
4. Detect characters.
5. Detect locations.
6. Generate shot list.
7. Generate camera directions.
8. Generate prompt package per shot.
9. Generate scene timing.
10. Export scene cards and prompts.
```

## Workflow 3: Character Bible

Required fields:

```json
{
  "characterId": "character_001",
  "name": "Character Name",
  "ageRange": "adult",
  "appearance": "locked appearance",
  "hair": "locked hair",
  "skinTone": "locked skin tone",
  "bodyType": "locked body type",
  "clothing": "locked clothing",
  "era": "locked era",
  "voiceStyle": "voice direction",
  "personality": "brief traits",
  "referenceImages": [],
  "consistencyRules": "Do not change face, age, wardrobe, or era.",
  "negativeTraitsToAvoid": "do not modernize wardrobe, do not alter identity"
}
```

## Workflow 4: Prompt Studio

Prompt types:

```text
image prompt
negative prompt
video prompt
voice prompt
music prompt
SFX prompt
subtitle prompt
narration prompt
continuity check prompt
rights metadata prompt
```

## Workflow 5: Continuity Check

Check:

```text
character face consistency
wardrobe consistency
era consistency
location continuity
scene order
voice consistency
visual style drift
missing assets
missing rights metadata
missing prompts
unverified outputs
```

---

# 12. Export Requirements

X-STUDIO-AI must export AI-built projects into the existing package structure.

## Required .loadstudio.zip / .cinepwa.zip Files

```text
index.html
manifest.json
service-worker.js
project.json
scenes.json
characters.json
rights.json
credits.json
styles.css
player.js
editor.js
assets/images/
assets/audio/
assets/music/
assets/sfx/
assets/subtitles/
assets/icons/
```

## Additional AI Files

```text
style-bible.json
voice-bible.json
wardrobe-bible.json
prompt-log.json
generation-report.json
continuity-report.json
model-routing.json
asset-declarations.json
```

These extra files should not break the validator. They should enhance the package.

---

# 13. UI Principle

The AI generator must not feel like a generic chatbox.

It should feel like a production control system.

Use this structure:

```text
Input
Plan
Generate
Review
Attach
Validate
Export
```

## Main UI Sections

```text
1. Source Material
2. Project Plan
3. Characters
4. Scenes
5. Prompts
6. Generation Queue
7. Outputs
8. Continuity
9. Rights & Safety
10. Export
```

---

# 14. Prompt-only Fallback

This is important.

Even if no model is connected, Load should still generate and export:

```text
scene cards
character bibles
style bibles
voice bibles
image prompts
video prompts
music/SFX prompts
negative prompts
rights metadata drafts
continuity reports
```

This means the system remains useful without API keys.

Label this mode:

```text
Prompt-only Mode
```

User-facing explanation:

```text
No generation model is connected. Load can still build structured scene plans, prompts, bibles, and export-ready project files for use with your preferred model.
```

---

# 15. Build Acceptance Criteria

The AI generator is not complete unless:

```text
1. Load Main has X-AI-CORE settings screen.
2. Model connector registry exists.
3. Capability detection exists.
4. Provider statuses exist.
5. Prompt-only fallback works.
6. Local/open-source connector placeholders exist.
7. Optional cloud providers are off by default.
8. No API keys are hard-coded.
9. Output proof rules exist.
10. Rights metadata writer exists.
11. Safety integration exists.
12. AI diagnostic report exports.
13. LoadStudio can open Load Creation Engine.
14. LoadStudio can generate scene cards from source text.
15. LoadStudio can generate character bible entries.
16. LoadStudio can generate style bible.
17. LoadStudio can generate image and video prompts.
18. LoadStudio can create prompt-log.json.
19. LoadStudio can create generation-report.json.
20. LoadStudio can attach outputs to scenes.
21. LoadStudio can export .loadstudio.zip / .cinepwa.zip.
22. Exported packages pass Load Main validator.
23. No success message appears without verified output.
24. Failed generation returns prompt and reason.
25. User can continue in prompt-only mode.
```

---

# 16. Claude-ready Full Prompt

Give Claude this after the Load Main v17g10 patch is complete.

```text
Claude, start the next major roadmap item: Load AI Model Independence System.

Before coding, read:
- SESSION_NOTES_2026-05-06.md
- CLAUDE.md
- current Load Main build notes
- current LoadStudio build notes

Do not start this if the Load Main v17g10 home-page discoverability patch is not complete and confirmed.

Goal:
Build the Load AI Model Independence System so Load has its own core AI infrastructure independent of any single provider, while allowing local models, open-source models, optional cloud providers, and future Load-hosted models.

This must be split into two build areas:

1. Load Main:
X-AI-CORE: Load AI Core and Model Independence Layer

2. LoadStudio:
X-STUDIO-AI: Load Creation Engine for AI Production

Do not build the full creative AI studio inside Load Main.
Do not build the AI creation engine inside LoadPlay.
Do not make any outside provider a hard dependency.
Do not hard-code API keys.
Do not mark generated output complete unless a real file/blob/URL exists.
Do not mark model connector READY unless a real test succeeds.

============================================================
PART 1: LOAD MAIN X-AI-CORE
============================================================

Build Load Main’s shared AI infrastructure layer.

Required Load Main screens:
- Load AI Core
- AI Core Settings
- Model Connectors
- Provider Status
- Prompt-only Fallback
- Project Memory
- Rights & Safety
- AI Diagnostics
- Export AI Report

Required modules:
- ai-core.js
- provider-router.js
- model-registry.js
- model-capabilities.js
- local-model-connector.js
- open-source-connector.js
- cloud-provider-connector.js
- prompt-only-connector.js
- project-memory.js
- output-proof.js
- rights-writer.js
- safety-ai-bridge.js
- ai-diagnostics.js
- ai-report-exporter.js

If the file structure differs, adapt to the existing project but keep these modules logically separated.

X-AI-CORE requirements:

1. Add provider/model routing independent of any single external API.
2. Support provider types: local, open-source, cloud-optional, load-hosted-future, prompt-only.
3. Support model capability detection for text, image, video, audio, voice, embeddings, safety, and document parsing.
4. Add provider statuses: Not configured, Ready, Failed, Rate limited, Unsupported request, Returned no file, Offline, Local server unavailable, Needs user setup.
5. Add fallback routing: local model where available, open-source connector, optional cloud provider, prompt-only fallback.
6. Keep all optional cloud providers off by default.
7. Add connector placeholders for local LLM server, ComfyUI, Stable Diffusion workflows, Piper, Kokoro TTS, FFmpeg, and future Load-hosted model server.
8. Add output proof rules.
9. Add project memory files.
10. Add rights metadata writer.
11. Add safety scanner integration.
12. Add AI diagnostic tests for each connector.
13. Add exportable AI diagnostic report.
14. Add prompt-only mode.
15. Add user-facing provider truth.

============================================================
PART 2: LOADSTUDIO X-STUDIO-AI
============================================================

Build LoadStudio’s creative AI production engine using Load Main’s X-AI-CORE.

Required LoadStudio screens:
- Load Creation Engine
- AI Scene Builder
- Book-to-Cinema
- Script-to-Shot
- Character Bible
- Style Bible
- Voice Bible
- Wardrobe Continuity
- Prompt Studio
- Generation Queue
- Output Review
- Continuity Check
- Export to LoadStudio Package

Required modules:
- creation-engine.js
- book-to-cinema.js
- script-to-shot.js
- scene-builder.js
- character-bible.js
- style-bible.js
- voice-bible.js
- wardrobe-bible.js
- prompt-studio.js
- generation-queue.js
- output-review.js
- continuity-checker.js
- export-loadstudio-package.js

X-STUDIO-AI requirements:
1. Add AI Scene Builder.
2. Add Book-to-Cinema workflow.
3. Add Script-to-Shot workflow.
4. Add Character Bible generator.
5. Add Style Bible generator.
6. Add Voice Bible generator.
7. Add Wardrobe Continuity tracker.
8. Add Prompt Studio.
9. Add Generation Queue.
10. Add Output Review.
11. Add Character Consistency checker.
12. Add Scene Consistency checker.
13. Add Continuity Check.
14. Attach generated assets to scenes.json.
15. Attach generated character data to characters.json.
16. Attach rights data to rights.json.
17. Create style-bible.json, voice-bible.json, wardrobe-bible.json, prompt-log.json, generation-report.json, continuity-report.json, model-routing.json, and asset-declarations.json.
18. Export AI-built projects as .loadstudio.zip and .cinepwa.zip.
19. Reopen and edit AI-built projects inside LoadStudio.
20. Use Load Main’s X-AI-CORE router.
21. Always allow prompt-only fallback if generation fails.
22. Failed generation must return failure reason, provider attempted, prompt used, and next recommended action.
23. No generated image/audio/video success message unless real file/blob/URL exists.

============================================================
PART 3: EXPORT PACKAGE REQUIREMENTS
============================================================

Exported AI-built projects must include the existing LoadStudio package structure plus AI files.

Exported packages must pass the existing Load Main LoadStudio validator.

============================================================
PART 4: UI PRINCIPLE
============================================================

Do not make this feel like a generic chatbox.

The UI should follow this production pipeline:

Input → Plan → Generate → Review → Attach → Validate → Export

Main sections:
1. Source Material
2. Project Plan
3. Characters
4. Scenes
5. Prompts
6. Generation Queue
7. Outputs
8. Continuity
9. Rights & Safety
10. Export

============================================================
PART 5: ACCEPTANCE CRITERIA
============================================================

The AI system is not complete unless all acceptance criteria in the master plan are met.

============================================================
PART 6: FINAL REPORT REQUIRED
============================================================

When complete, provide:
1. Exact files changed.
2. Exact files added.
3. Exact files to upload.
4. Confirmation that only necessary files were changed.
5. New screens added.
6. New modules added.
7. Connector registry status.
8. Provider routing behavior.
9. Prompt-only fallback proof.
10. Output proof rules proof.
11. Rights metadata proof.
12. Safety integration proof.
13. LoadStudio workflow proof.
14. Export package proof.
15. Validator pass/fail results.
16. Rows that are VERIFIED.
17. Rows that are READY FOR USER VERIFICATION.
18. Rows that are NOT DONE.
19. Known limitations.
20. Next recommended build step.

Do not mark anything complete without a visible test or code-level proof.
```

---

# 17. Final Recommendation

Do not give this to Claude as part of the small v17g10 patch. It is too large and will cause drift.

Use it after:

```text
Load Main v17g10 home-page handoff shortcut row is complete.
```

Then this becomes the next major roadmap build.



---

# PART 3: UPDATED AI CHAT STUDIO + MOVIE/CONTENT PRODUCTION ADDENDUM

# Updated AI Chat Studio and Movie/Content Production Requirements

## Why these features are core

The AI image/chat/animation features are not optional decoration. They are central to the LoadStudio content and movie-building pipeline.

The practical production bridge is:

```text
source material → AI chat → image generation → style control → image animation → scene building → package export → playback → future distribution
```

The chat feature should not be only a planning assistant. It should be a conversational generation surface that can create and refine usable visual and motion assets for LoadStudio.

## Required AI Chat Studio feature scope

The chat feature must support:

1. Chat input box.
2. Prompt refinement.
3. Conversation history.
4. Project-linked chat history.
5. Output type selector.
6. Text-to-image generation.
7. Image-to-image generation.
8. Multi-style image generation.
9. Style selector.
10. Reference image upload.
11. Regenerate / variation tools.
12. Save generated image to project.
13. Attach generated image to scene.
14. Animate still image.
15. Image-to-video generation or animation-ready prompt generation.
16. Motion prompt input.
17. Save generated animation/video to project.
18. Attach animation/video to scene.
19. Output review.
20. Prompt-only fallback.

## What not to build

Do not build this as a clone of a beauty, social-effect, or viral makeover app.

Do not build:

- beauty filters
- glamour effects
- viral social effects
- AI photoshoots as the main product
- face retouching
- makeover tools
- entertainment-first trend features

Build only a Load-native creation surface for content, movies, books, scripts, and PWA cinema packages.

## Load ecosystem placement

### Load Main

Load Main owns:

- X-AI-CORE
- model/provider routing
- local/open-source model support
- optional cloud model connectors
- provider diagnostics
- output proof rules
- rights metadata writer
- safety integration
- AI diagnostic report
- prompt-only fallback
- shared project memory

Load Main should not become the full creative studio.

### LoadStudio

LoadStudio owns:

- X-AI-CHAT-STUDIO
- X-STUDIO-AI
- AI Chat Studio
- image generation UI
- image-to-image UI
- style selector
- reference image upload
- animation/motion prompt UI
- scene attachment
- project saving
- package export

### LoadPlay

LoadPlay should not become the AI creation center. Later it can use AI for catalog tagging, captions, moderation, upload review, thumbnail suggestions, search enrichment, and rights review.

## X-AI-CORE requirements

X-AI-CORE must support:

1. Provider/model routing independent of a single external API.
2. Local-first mode with no API key.
3. Open-source model connectors.
4. Optional commercial/cloud providers only when enabled by user.
5. Optional cloud providers off by default.
6. Capability detection:
   - text
   - image
   - video
   - audio
   - voice
   - embeddings
   - safety
   - document parsing
7. Provider status labels:
   - Not configured
   - Ready
   - Failed
   - Rate limited
   - Unsupported request
   - Returned no file
   - Offline
   - Local server unavailable
   - Needs user setup
8. Fallback routing:
   - local model where available
   - open-source connector
   - optional cloud provider
   - prompt-only fallback
9. Output proof rules:
   - never claim image generation unless file/blob/URL exists
   - never claim animated output unless playable file/blob/URL exists
   - never claim video generation unless playable file/blob/URL exists
   - never claim audio generation unless playable file/blob exists
   - never claim text generation unless non-empty text exists
   - never claim ZIP/package generation unless the file is real and valid
10. Project memory schema.
11. Rights metadata writer.
12. Safety scanner integration.
13. Diagnostic tests for each connector.
14. Exportable AI diagnostic report.

## X-AI-CHAT-STUDIO requirements

Required screens:

- Load AI Chat Studio
- Chat Workspace
- Style Picker
- Output Type Selector
- Reference Upload
- Generation History
- Output Review
- Attach to Project

Suggested modules:

```text
/loadstudio/ai-chat/index.html
/loadstudio/ai-chat/chat-studio.js
/loadstudio/ai-chat/chat-history.js
/loadstudio/ai-chat/output-selector.js
/loadstudio/ai-chat/style-selector.js
/loadstudio/ai-chat/reference-upload.js
/loadstudio/ai-chat/image-generator.js
/loadstudio/ai-chat/image-refiner.js
/loadstudio/ai-chat/image-animator.js
/loadstudio/ai-chat/project-attach.js
/loadstudio/ai-chat/chat-export.js
```

Required behavior:

1. User enters a creation request in chat.
2. User may upload a source image or source material.
3. User chooses output type:
   - image
   - animated image
   - video prompt
   - scene prompt
   - package-ready output
4. User chooses style or uses project style bible.
5. System routes request through X-AI-CORE.
6. System returns generated output or structured prompt fallback.
7. User refines through chat.
8. User saves output to project.
9. User attaches output to scene.
10. System writes structured logs and output metadata.

## X-STUDIO-AI requirements

X-STUDIO-AI should include:

- AI Scene Builder
- Book-to-Cinema workflow
- Script-to-Shot workflow
- Character Bible generator
- Style Bible generator
- Voice Bible generator
- Wardrobe Continuity tracker
- Prompt Studio
- Generation Queue
- Output Review
- Character Consistency checker
- Scene Consistency checker
- Continuity Check
- Export to LoadStudio package

It should create:

- scenes.json
- characters.json
- rights.json
- credits.json
- style-bible.json
- voice-bible.json
- wardrobe-bible.json
- prompt-log.json
- generation-report.json
- continuity-report.json
- model-routing.json
- asset-declarations.json
- chat-history.json

## Package requirements

AI-built projects must still export into the existing LoadStudio package structure:

```text
index.html
manifest.json
service-worker.js
project.json
scenes.json
characters.json
rights.json
credits.json
styles.css
player.js
editor.js
assets/images/
assets/audio/
assets/music/
assets/sfx/
assets/subtitles/
assets/icons/
```

Additional AI files should enhance the package without breaking validation:

```text
style-bible.json
voice-bible.json
wardrobe-bible.json
prompt-log.json
generation-report.json
continuity-report.json
model-routing.json
asset-declarations.json
chat-history.json
```

## Movie/content workflow

The target production flow:

1. Import or paste source material.
2. Use AI Chat Studio to define the visual intent.
3. Generate image prompts or real image outputs.
4. Choose style or project style bible.
5. Refine images through chat.
6. Animate still images or produce animation-ready prompts.
7. Attach images/animation outputs to scenes.
8. Generate scene cards and continuity reports.
9. Save everything into structured files.
10. Export .loadstudio.zip / .cinepwa.zip.
11. Reopen and edit the project.
12. Validate in Load Main.
13. Later prepare for LoadPlay.

## Acceptance criteria

The system is not complete unless:

1. Load Main has X-AI-CORE screens.
2. Model connector registry exists.
3. Capability detection exists.
4. Provider statuses exist.
5. Prompt-only fallback works.
6. Optional cloud providers are off by default.
7. No API keys are hard-coded.
8. Output proof rules exist.
9. Rights metadata writer exists.
10. Safety integration exists.
11. AI diagnostic report exports.
12. LoadStudio can open AI Chat Studio.
13. AI Chat Studio can create image requests.
14. AI Chat Studio can create style-based image outputs or fallback prompts.
15. AI Chat Studio can animate still images or return animation-ready prompts.
16. LoadStudio can generate scene cards.
17. LoadStudio can generate character bible entries.
18. LoadStudio can create prompt-log.json.
19. LoadStudio can create generation-report.json.
20. LoadStudio can attach outputs to scenes.
21. LoadStudio can export .loadstudio.zip / .cinepwa.zip.
22. Exported packages pass Load Main validator.
23. No success message appears without verified output.
24. Failed generation returns prompt and reason.
25. User can continue in prompt-only mode.


---

# PART 4: CONDENSED CLAUDE EXECUTION ORDER

Use this order to avoid drift:

1. Finish the Load Main v17g10 home-page discoverability patch.
2. Confirm the Handoff Verification Tools row is visible on /load/.
3. Confirm Run All Tests, Build PWA ZIP, LoadStudio Package Validator, Rights & Safety Validator, Sandbox Preview, and Report Proof links work.
4. Do not start AI build until this is complete.
5. Add X-AI-CORE roadmap entry to Load Main.
6. Build X-AI-CORE minimum viable infrastructure.
7. Build X-AI-CHAT-STUDIO in LoadStudio.
8. Connect AI Chat Studio to existing Load AI Image function if it works.
9. Build image generation, image-to-image, style selector, reference upload, and prompt-only fallback.
10. Build still-image animation and image-to-video routing or motion prompt fallback.
11. Build X-STUDIO-AI scene/project structure.
12. Export .loadstudio.zip / .cinepwa.zip.
13. Validate exported package in Load Main.
14. Later connect to X-VIDEO-AI, X-DB, and X-SUBS.

---

# PART 5: FINAL NON-NEGOTIABLES

- Do not mark features complete without visible test or code-level proof.
- Do not claim generated image success unless real file/blob/URL exists.
- Do not claim animation/video success unless playable file/blob/URL exists.
- Do not hard-code API keys.
- Keep optional cloud providers off by default.
- Preserve local-first strategy.
- Preserve Load Main as infrastructure and validation hub.
- Preserve LoadStudio as the creative production cockpit.
- Do not make LoadPlay the AI creation center.
- Keep AI outputs structured, editable, exportable, and package-ready.
