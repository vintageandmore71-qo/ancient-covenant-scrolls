# Updated AI Chat Studio and Movie/Content Production Requirements

## Why these features are core

The AI image/chat/animation features are not optional decoration. They are central to the LoadStudio content and movie-building pipeline.

The practical production bridge is:

```text
source material → AI chat → image generation → style control → image animation → scene building → package export → playback → future distribution
```

The chat feature should not be only a planning assistant. It should be a conversational generation surface that can create and refine usable visual and motion assets for LoadStudio.

## Required AI Chat Studio feature scope

The chat feature must support:

1. Chat input box.
2. Prompt refinement.
3. Conversation history.
4. Project-linked chat history.
5. Output type selector.
6. Text-to-image generation.
7. Image-to-image generation.
8. Multi-style image generation.
9. Style selector.
10. Reference image upload.
11. Regenerate / variation tools.
12. Save generated image to project.
13. Attach generated image to scene.
14. Animate still image.
15. Image-to-video generation or animation-ready prompt generation.
16. Motion prompt input.
17. Save generated animation/video to project.
18. Attach animation/video to scene.
19. Output review.
20. Prompt-only fallback.

## What not to build

Do not build this as a clone of a beauty, social-effect, or viral makeover app.

Do not build:

- beauty filters
- glamour effects
- viral social effects
- AI photoshoots as the main product
- face retouching
- makeover tools
- entertainment-first trend features

Build only a Load-native creation surface for content, movies, books, scripts, and PWA cinema packages.

## Load ecosystem placement

### Load Main

Load Main owns:

- X-AI-CORE
- model/provider routing
- local/open-source model support
- optional cloud model connectors
- provider diagnostics
- output proof rules
- rights metadata writer
- safety integration
- AI diagnostic report
- prompt-only fallback
- shared project memory

Load Main should not become the full creative studio.

### LoadStudio

LoadStudio owns:

- X-AI-CHAT-STUDIO
- X-STUDIO-AI
- AI Chat Studio
- image generation UI
- image-to-image UI
- style selector
- reference image upload
- animation/motion prompt UI
- scene attachment
- project saving
- package export

### LoadPlay

LoadPlay should not become the AI creation center. Later it can use AI for catalog tagging, captions, moderation, upload review, thumbnail suggestions, search enrichment, and rights review.

## X-AI-CORE requirements

X-AI-CORE must support:

1. Provider/model routing independent of a single external API.
2. Local-first mode with no API key.
3. Open-source model connectors.
4. Optional commercial/cloud providers only when enabled by user.
5. Optional cloud providers off by default.
6. Capability detection:
   - text
   - image
   - video
   - audio
   - voice
   - embeddings
   - safety
   - document parsing
7. Provider status labels:
   - Not configured
   - Ready
   - Failed
   - Rate limited
   - Unsupported request
   - Returned no file
   - Offline
   - Local server unavailable
   - Needs user setup
8. Fallback routing:
   - local model where available
   - open-source connector
   - optional cloud provider
   - prompt-only fallback
9. Output proof rules:
   - never claim image generation unless file/blob/URL exists
   - never claim animated output unless playable file/blob/URL exists
   - never claim video generation unless playable file/blob/URL exists
   - never claim audio generation unless playable file/blob exists
   - never claim text generation unless non-empty text exists
   - never claim ZIP/package generation unless the file is real and valid
10. Project memory schema.
11. Rights metadata writer.
12. Safety scanner integration.
13. Diagnostic tests for each connector.
14. Exportable AI diagnostic report.

## X-AI-CHAT-STUDIO requirements

Required screens:

- Load AI Chat Studio
- Chat Workspace
- Style Picker
- Output Type Selector
- Reference Upload
- Generation History
- Output Review
- Attach to Project

Suggested modules:

```text
/loadstudio/ai-chat/index.html
/loadstudio/ai-chat/chat-studio.js
/loadstudio/ai-chat/chat-history.js
/loadstudio/ai-chat/output-selector.js
/loadstudio/ai-chat/style-selector.js
/loadstudio/ai-chat/reference-upload.js
/loadstudio/ai-chat/image-generator.js
/loadstudio/ai-chat/image-refiner.js
/loadstudio/ai-chat/image-animator.js
/loadstudio/ai-chat/project-attach.js
/loadstudio/ai-chat/chat-export.js
```

Required behavior:

1. User enters a creation request in chat.
2. User may upload a source image or source material.
3. User chooses output type:
   - image
   - animated image
   - video prompt
   - scene prompt
   - package-ready output
4. User chooses style or uses project style bible.
5. System routes request through X-AI-CORE.
6. System returns generated output or structured prompt fallback.
7. User refines through chat.
8. User saves output to project.
9. User attaches output to scene.
10. System writes structured logs and output metadata.

## X-STUDIO-AI requirements

X-STUDIO-AI should include:

- AI Scene Builder
- Book-to-Cinema workflow
- Script-to-Shot workflow
- Character Bible generator
- Style Bible generator
- Voice Bible generator
- Wardrobe Continuity tracker
- Prompt Studio
- Generation Queue
- Output Review
- Character Consistency checker
- Scene Consistency checker
- Continuity Check
- Export to LoadStudio package

It should create:

- scenes.json
- characters.json
- rights.json
- credits.json
- style-bible.json
- voice-bible.json
- wardrobe-bible.json
- prompt-log.json
- generation-report.json
- continuity-report.json
- model-routing.json
- asset-declarations.json
- chat-history.json

## Package requirements

AI-built projects must still export into the existing LoadStudio package structure:

```text
index.html
manifest.json
service-worker.js
project.json
scenes.json
characters.json
rights.json
credits.json
styles.css
player.js
editor.js
assets/images/
assets/audio/
assets/music/
assets/sfx/
assets/subtitles/
assets/icons/
```

Additional AI files should enhance the package without breaking validation:

```text
style-bible.json
voice-bible.json
wardrobe-bible.json
prompt-log.json
generation-report.json
continuity-report.json
model-routing.json
asset-declarations.json
chat-history.json
```

## Movie/content workflow

The target production flow:

1. Import or paste source material.
2. Use AI Chat Studio to define the visual intent.
3. Generate image prompts or real image outputs.
4. Choose style or project style bible.
5. Refine images through chat.
6. Animate still images or produce animation-ready prompts.
7. Attach images/animation outputs to scenes.
8. Generate scene cards and continuity reports.
9. Save everything into structured files.
10. Export .loadstudio.zip / .cinepwa.zip.
11. Reopen and edit the project.
12. Validate in Load Main.
13. Later prepare for LoadPlay.

## Acceptance criteria

The system is not complete unless:

1. Load Main has X-AI-CORE screens.
2. Model connector registry exists.
3. Capability detection exists.
4. Provider statuses exist.
5. Prompt-only fallback works.
6. Optional cloud providers are off by default.
7. No API keys are hard-coded.
8. Output proof rules exist.
9. Rights metadata writer exists.
10. Safety integration exists.
11. AI diagnostic report exports.
12. LoadStudio can open AI Chat Studio.
13. AI Chat Studio can create image requests.
14. AI Chat Studio can create style-based image outputs or fallback prompts.
15. AI Chat Studio can animate still images or return animation-ready prompts.
16. LoadStudio can generate scene cards.
17. LoadStudio can generate character bible entries.
18. LoadStudio can create prompt-log.json.
19. LoadStudio can create generation-report.json.
20. LoadStudio can attach outputs to scenes.
21. LoadStudio can export .loadstudio.zip / .cinepwa.zip.
22. Exported packages pass Load Main validator.
23. No success message appears without verified output.
24. Failed generation returns prompt and reason.
25. User can continue in prompt-only mode.
