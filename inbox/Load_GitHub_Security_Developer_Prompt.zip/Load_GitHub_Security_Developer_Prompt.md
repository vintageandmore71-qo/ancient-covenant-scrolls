# Load GitHub Security Developer Prompt

```txt
Please harden my public GitHub repository for a PWA/app project called Load.

This repo is public, so treat everything inside it as visible to the entire internet.

Your job is to make the repository as safe as possible while keeping it usable for development.

IMPORTANT:
Do not break the app.
Do not remove working features.
Do not expose any API keys, tokens, passwords, private URLs, admin bypasses, .env files, database credentials, or production secrets in the public repo.

SECURITY TASKS:

1. Secret audit
Search the entire repository for:
- API keys
- tokens
- passwords
- private URLs
- admin passwords
- admin bypass links
- .env files
- Firebase credentials
- Supabase credentials
- OpenRouter keys
- Hugging Face tokens
- Cloudflare keys
- Google/Gemini keys
- Puter-related secrets
- any provider credentials
- private user data
- copyrighted paid assets
- unreleased private business notes

If any real secret is found:
- stop and tell me exactly where it was found
- remove it from the code
- replace it with a placeholder
- tell me the key must be revoked and regenerated
- do not commit real secrets back into the repo

2. Add or update .gitignore
Create or update .gitignore so it blocks:
- .env
- .env.*
- node_modules
- build outputs
- logs
- cache files
- local config files
- keys
- certificates
- local databases
- secret files
- private credential files

Keep .env.example allowed.

3. Add .env.example
Create a .env.example file with placeholder values only.
Do not include real keys.

Example:
OPENROUTER_API_KEY=replace_with_server_side_secret_only
HUGGINGFACE_TOKEN=replace_with_server_side_secret_only
CLOUDFLARE_API_TOKEN=replace_with_server_side_secret_only
GEMINI_API_KEY=replace_with_server_side_secret_only
PUTER_ENABLED=true
POLLINATIONS_ENABLED=true

Important:
If this app uses VITE variables, remember VITE variables are visible in frontend builds.
Do not place private keys in VITE variables.

4. Move secrets out of frontend code
Inspect the app for provider calls.
If any AI provider key or privileged API call is inside browser/frontend code, move it behind a backend or serverless proxy.

Preferred safe structure:
Public Load PWA frontend
→ backend/serverless proxy
→ private provider keys stored in environment variables
→ AI provider API

Possible free/free-tier proxy options:
- Cloudflare Workers
- Netlify Functions
- Vercel Serverless Functions
- Supabase Edge Functions
- Firebase Functions

5. Add GitHub security files
Add these files if missing:
- SECURITY.md
- .github/pull_request_template.md
- .github/dependabot.yml
- .github/workflows/codeql.yml
- CODEOWNERS if appropriate

6. Add SECURITY.md
Create a SECURITY.md that says:
- do not report security problems in public issues
- report them privately
- do not submit API keys, passwords, tokens, .env files, private data, paid assets, or production credentials
- this repo is public and must never contain secrets

7. Add pull request template
Add a PR checklist that requires confirmation:
- no API keys added
- no .env file added
- no provider keys exposed in frontend code
- no private user data added
- no paid/copyrighted assets added without approval
- app still builds
- app still runs

8. Add Dependabot
Add .github/dependabot.yml for npm weekly updates.

9. Add CodeQL
Add GitHub Actions CodeQL scanning for JavaScript/TypeScript.

10. Branch protection guidance
Prepare instructions for me to manually enable branch protection on GitHub:
- protect main branch
- no direct pushes to main
- require pull request before merge
- require at least one review
- require status checks
- require conversation resolution
- block force pushes
- block branch deletion

11. Add local scan instructions
Tell me how to run free local security checks before pushing:
- gitleaks
- trufflehog
- npm audit or pnpm audit

12. Final security report
After finishing, give me a report with:
- what you changed
- what files you added
- what secrets or risks you found
- what I need to enable manually in GitHub settings
- what should stay out of the public repo
- whether any exposed key must be revoked
- any remaining public-repo risks

Again:
Do not break existing app behavior.
Do not expose secrets.
Do not commit real keys.
Do not pretend the repo is safe if public risks remain.

```
