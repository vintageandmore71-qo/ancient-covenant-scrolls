# Load GitHub Public Repository Security Prompt

This zip contains a copy-paste developer prompt for hardening a public GitHub repository for the Load PWA/app project.

Files included:
- `Load_GitHub_Security_Developer_Prompt.txt`
- `Load_GitHub_Security_Developer_Prompt.md`

Use either file and paste the prompt directly into your developer or AI builder.
