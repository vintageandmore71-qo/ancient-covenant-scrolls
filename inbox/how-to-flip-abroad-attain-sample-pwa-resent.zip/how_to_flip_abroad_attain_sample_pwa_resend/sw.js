const CACHE_NAME='flip-abroad-attain-resend-v1';
const ASSETS=["./", "./index.html", "./manifest.json", "./book-data.json", "./assets/cover.jpg", "./assets/icon-192.png", "./assets/icon-512.png", "./assets/timeline-search-to-close.png", "./assets/budget-stack-chart.png", "./assets/renovation-risk-matrix.png", "./assets/buying-differences-table.png", "./assets/due-diligence-infographic.png"];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(ASSETS)));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))));self.clients.claim();});
self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request)));});