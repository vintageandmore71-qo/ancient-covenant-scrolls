OPEN THIS FILE: index.html

Do not open manifest.json, sw.js, or book-data.json directly. Those files are supposed to show code/data.

Included:
- standalone digital book PWA
- 11 readable sections
- 13 quiz questions
- 5 visible chart/image assets
- cover, icons, manifest, service worker, book-data.json
- night mode, dyslexia mode, larger text, progress bar, quiz reset
