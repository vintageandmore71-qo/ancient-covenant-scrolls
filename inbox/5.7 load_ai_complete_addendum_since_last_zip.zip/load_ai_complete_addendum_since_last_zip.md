# Load AI Chat Complete Addendum Since Last ZIP
## Claude-ready package of all new information added after the previous ZIP

Prepared for Claude handoff  
Purpose: Consolidate every major new requirement, correction, extension, and provider strategy update added after the last AI/Load ZIP so Claude can continue without drift.

IMPORTANT:
This is an addendum to the prior Load AI Cinema System ZIP and related addenda.
Do not replace the previous ZIP.
Use this file as the authoritative update containing all major new information added after that ZIP.

---

# 1. Master rule locked in

For Load AI Chat and related Load ecosystem builds:

```text
Free / open-source / local-first providers only for MVP.
Built-in Load tools first.
Paid providers only as future optional connectors, off by default.
No hard dependency on expensive APIs.
No hard-coded keys.
No exported keys.
```

Do not make ElevenLabs, Replicate, Stability AI, or other expensive paid providers MVP requirements.

They may only appear as:

```text
Future optional paid connectors
```

They must be:

```text
off by default
not required
not blocking
not used as the main route
not hard-coded
not exported
```

---

# 2. Glam AI Chat pattern: what Load must emulate

The user examples clarified that the target is not a normal chatbot and not a separate hidden generator.

The target pattern is:

```text
User types request
System generates image inside chat
System shows actions under the output
User asks for changes
User asks to animate the image
System shows a progress or “Almost Ready” state
System returns the final animated result inside the same chat
User saves, extends, refines, exports, or attaches to scene
```

For Load, this must become:

```text
Chat-driven creation workflow inside Load AI Chat Studio
```

The chat is the creative control center for:

- text-to-image generation
- image-to-image generation
- style selection
- inline image results
- follow-up refinements
- still-image animation
- performance-style animation
- sound/SFX/ambience intent
- real sound generation or attachment
- scene attachment
- package-ready output

---

# 3. New core requirement: real sound must be available

Sound is not optional.

The corrected target is:

```text
Load AI Chat Studio must support image animation with real audio when available, and must support separate sound/SFX generation as a fallback when the video model itself cannot embed sound.
```

Load must support three sound paths:

## Path 1: Embedded video audio

If the selected image-to-video provider supports audio, Load should request and return a video with embedded sound.

## Path 2: Separate generated audio/SFX

If the video provider returns silent video, Load must generate or attach separate audio/SFX tracks and attach them to the scene.

## Path 3: Sound prompt fallback

If no audio provider is available, Load must save the sound prompt into the scene so audio can be generated later.

### MVP priority

The MVP should prioritize:

```text
silent video + separate generated audio/SFX + scene attachment
```

Do not wait for embedded-audio video providers.

---

# 4. New required feature: X-AI-AUDIO

Add a new major feature:

```text
X-AI-AUDIO: Sound and Atmosphere Engine
```

Purpose:
X-AI-AUDIO gives Load AI Chat Studio and LoadStudio the ability to generate, attach, layer, and export real sound for animated image/video scenes.

Required support:

- text-to-sound effect
- text-to-ambience
- text-to-music cue
- crowd sounds
- laughter
- mocking laughter
- weather
- animals
- footsteps
- marketplace/city noise
- wood hammering
- fire
- wind
- water
- battle sounds
- narration/voice if connected

Required user-facing sound features:

- Add sound to animation
- Generate sound effects
- Generate ambient background sound
- Generate crowd noise
- Generate laughter
- Generate weather
- Generate animal sounds
- Generate footsteps
- Generate environmental sound
- Generate music cue
- Generate narration or voice if connected
- Attach audio to scene
- Replace audio
- Layer multiple sound tracks
- Export scene with audio references
- Later mux audio into video if supported

---

# 5. Load must handle sound honestly

Load must separate these concepts clearly:

```text
Sound Prompt
Actual Audio Track
Embedded Audio in Video
Separate SFX Layer
```

Required status labels:

```text
Audio embedded
Separate audio generated
Sound prompt saved
Audio provider needed
Silent video
Audio failed
Audio ready for scene
Audio ready for export
Audio muxing available
Audio muxing not available
Audio muxing future
```

If video is silent, say it is silent.
If sound was only saved as a prompt, say so.
If actual sound exists, identify whether it is embedded or separate.

---

# 6. New requirement: sound-aware image animation workflow

When user says something like:

```text
Bring this image to life, have noise and mocking laughter.
```

The system must split it into structured parts:

```json
{
  "sourceImage": "asset-id",
  "outputType": "image_to_video_with_sound",
  "visualPrompt": "Animate the ark scene with people moving, mockers gesturing and laughing, workers building, dust and wind in the air.",
  "motionPrompt": "Slow cinematic camera movement, crowd shifting, fabric moving, workers hammering wood.",
  "soundPrompt": "Noisy crowd, mocking laughter, men jeering, wood hammering, distant animals.",
  "musicPrompt": "Low tense ancient cinematic underscore.",
  "requires": {
    "imageToVideo": true,
    "audio": true,
    "sfx": true
  }
}
```

Routing logic:

```text
1. Identify the active image.
2. Check image-to-video providers.
3. If provider supports embedded audio, request it.
4. If provider returns silent video, route soundPrompt to X-AI-AUDIO.
5. If audio/SFX provider exists, generate separate audio/SFX files.
6. If no audio provider exists, save soundPrompt and label Audio provider needed.
7. Attach all outputs to scene.
8. Write prompt/output metadata.
```

---

# 7. New requirement: AI Chat Studio must be multimodal and project-aware

Load AI Chat Studio must support:

- natural-language prompt input
- inline image result cards
- text-to-image generation
- image-to-image generation
- multi-style image generation
- style selector
- reference image upload
- regenerate/variation tools
- save generated image to project
- attach generated image to scene
- follow-up command such as “Animate this”
- animate still image
- image-to-video generation or prompt fallback
- animation progress/waiting state
- inline video result card
- save generated animation/video to project
- attach generated animation/video to scene
- extend animation option
- project-linked chat history
- prompt-only fallback if no model is connected

---

# 8. Two animation levels Load must support

## Level 1: Light image animation

Support:

- camera push-in
- gentle parallax
- soft environmental movement
- subtle portrait motion
- background light movement

## Level 2: Performance-style image animation

Support:

- head turns
- facial expression changes
- body movement
- hair/clothing motion
- identity preservation
- background/scene continuity

This second level is essential for movie/content production.

---

# 9. Existing Load Main key/provider settings must be reused

IMPORTANT CORRECTION:

Load Main already has a place for provider/API keys.

Do not build a second API key settings system.

Do not create a second key vault.
Do not duplicate provider settings.
Do not duplicate the UI.

Instead:

1. Audit the existing Load Main provider/API key settings.
2. Identify existing provider rows.
3. Identify where keys are stored.
4. Identify existing test buttons or readiness checks.
5. Extend the existing provider settings only where needed.
6. Add capability detection to existing provider entries.
7. Add missing provider rows only where needed.
8. Keep all optional cloud providers off by default.
9. Never hard-code API keys.
10. Never include API keys in exported ZIPs, project files, reports, logs, rights metadata, asset declarations, export receipts, or security reports.

If localStorage is used:

```text
Show warning: API keys are stored locally in this browser. Do not use this on shared devices.
```

Future backend proxy support may be listed as future work.

---

# 10. Existing Load AI Image function must be audited first

Before building any new image generator, audit the existing Load AI Image function.

Report:

1. UI location
2. file/module location
3. current provider used
4. whether it supports text-to-image
5. whether it supports image-to-image
6. whether it supports style selection
7. whether it supports reference image upload
8. whether it supports negative prompts
9. whether it returns a real image file/blob/URL
10. whether output can be saved to Library
11. whether output can attach to LoadStudio `scene.image`
12. whether prompt and negativePrompt are stored
13. whether generation errors are handled honestly
14. whether it can become the foundation for Load AI Chat Studio image generation

Required rule:

```text
Do not rebuild image generation from scratch if the existing Load AI Image function works. Extend it.
```

Proof rule:

```text
Do not claim the built-in Load AI Image function works unless a real image file/blob/URL is returned.
```

---

# 11. Provider/plugin/API-key layer must be explicit

The prior plan covered architecture and workflow.
This addendum adds the required provider/plugin/built-in-tool layer.

Load AI Chat must realistically generate or route:

- images
- image-to-image outputs
- multi-style images
- image animation
- image-to-video
- realistic sound effects
- ambience and atmosphere
- crowd noise
- laughter and mocking laughter
- weather
- animal sounds
- music cues
- voices
- narration
- project-ready assets

---

# 12. Shared provider registry requirement

Create or extend a shared provider registry used by:

- X-AI-CORE
- Load AI Chat Studio
- LoadStudio AI tools
- future X-VIDEO-AI
- future X-AI-AUDIO

Each provider entry must include something like:

```json
{
  "providerId": "provider-name",
  "providerName": "Human readable name",
  "providerType": "built-in | free-api | local | open-source | user-imported | prompt-only | future-paid-optional | load-hosted-future",
  "enabled": false,
  "requiresApiKey": false,
  "apiKeyStorageName": "",
  "requiresLocalServer": false,
  "endpoint": "",
  "capabilities": {
    "text": false,
    "image": false,
    "imageToImage": false,
    "inpainting": false,
    "upscale": false,
    "faceRestore": false,
    "styleTransfer": false,
    "referenceImage": false,
    "imageAnimation": false,
    "video": false,
    "motionPrompt": false,
    "performanceAnimation": false,
    "audio": false,
    "sfx": false,
    "ambience": false,
    "music": false,
    "voice": false,
    "narration": false,
    "local": false,
    "free": false,
    "requiresApiKey": false,
    "requiresLocalServer": false,
    "documentParsing": false,
    "safety": false
  },
  "status": "Not configured",
  "lastTestedAt": null
}
```

Allowed statuses:

- Not configured
- Ready
- Failed
- Rate limited
- Unsupported request
- Returned no file
- Offline
- Local server unavailable
- Needs user setup

---

# 13. Current 17 image providers in Load must be audited and extended

Current image providers in code:

```text
1. Local SD, A1111-compatible via localSdUrl
2. Pollinations Flux
3. Pollinations classic
4. Hugging Face cascade: SDXL / SD-1.5 / FLUX + SDXL Inpainting
5. Cloudflare AI, FLUX-schnell
6. Together AI, FLUX-schnell-Free
7. AI Horde anonymous
8. Google Imagen / Gemini 2.5 Flash Image
9. DeepAI
10. Pollinations Turbo
11. AI Horde SDXL anonymous
12. Cloudflare SDXL-Lightning
13. HF SDXL-Turbo
14. SiliconFlow FLUX.1 Kontext img2img + FLUX.1-schnell
15. Real-ESRGAN via HF token, upscale taskOnly
16. GFPGAN via HF token, face restoration taskOnly
17. CodeFormer via HF token, face restoration alt taskOnly
```

These should be audited and kept/extended according to the free/open/local rule.

### Status recommendations

| # | Current provider | Recommendation |
|---:|---|---|
| 1 | Local SD, A1111-compatible via `localSdUrl` | Keep. Strong local-first route. Add/align with ComfyUI later. |
| 2 | Pollinations Flux | Keep. Free/community route if working. |
| 3 | Pollinations classic | Keep. Useful fallback. |
| 4 | Hugging Face cascade: SDXL / SD-1.5 / FLUX + SDXL Inpainting | Keep if free/user-configured. Optional key route only. |
| 5 | Cloudflare AI, FLUX-schnell | Keep optional/free-tier only. Off by default unless configured. |
| 6 | Together AI, FLUX-schnell-Free | Keep optional/free-tier only if truly free in current setup. |
| 7 | AI Horde anonymous | Keep. Strong free/community fallback. |
| 8 | Google Imagen / Gemini 2.5 Flash Image | Optional only. Key-based. Not MVP-critical. |
| 9 | DeepAI | Optional only. Key-based. Not priority. |
| 10 | Pollinations Turbo | Keep. Free/community route if working. |
| 11 | AI Horde SDXL anonymous | Keep. Useful free/community route. |
| 12 | Cloudflare SDXL-Lightning | Keep optional/free-tier only. |
| 13 | HF SDXL-Turbo | Keep if free/user-configured. |
| 14 | SiliconFlow FLUX.1 Kontext img2img + FLUX.1-schnell | Optional only. Key-based. Off by default. |
| 15 | Real-ESRGAN via HF token, upscale taskOnly | Keep as task tool. |
| 16 | GFPGAN via HF token, face restoration taskOnly | Keep as task tool. |
| 17 | CodeFormer via HF token, face restoration alt taskOnly | Keep as task tool. |

Important:
The existing 17 are mostly image generation and image repair. They do not fully cover animation, SFX, ambience, music, narration, or local audio/video pipeline needs. Extend the registry instead of replacing the 17.

---

# 14. New provider categories that must be added

## A. Image animation and image-to-video

Add these rows or placeholders:

```text
ComfyUI connector
ComfyUI AnimateDiff workflow
ComfyUI video workflow
Prompt-only motion provider
LTX-Video local workflow placeholder
Wan video local workflow placeholder
Local video model server placeholder
Future Load Local Engine video connector
```

Purpose:

```text
animate still image
image-to-video
motion prompt
camera movement
character motion
environment motion
performance-style image animation
preserve identity where possible
preserve scene/background where possible
return playable video file/blob/URL
```

Do not require paid image-to-video providers for MVP.

## B. Sound effects and ambience

Add these rows or placeholders:

```text
Prompt-only sound design provider
User-imported SFX library
Local/public-domain SFX library
Local ambience library
Hugging Face open-source audio models where free/practical
Local audio model server placeholder
Future Load Local Engine audio connector
```

Purpose:

```text
crowd noise
mocking laughter
general laughter
weather
wind
rain
fire
water
animals
footsteps
wood hammering
marketplace/city noise
battle sounds
room tone
nature atmosphere
ancient outdoor atmosphere
```

Do not bundle copyrighted SFX packs.

Use:

```text
user-owned
public-domain
CC0
properly licensed
```

## C. Voice and narration

Add these rows or placeholders:

```text
Browser TTS
Piper
Kokoro TTS future local connector
User recording
Load voice manipulator
Hugging Face TTS models where free/practical
Future Load Local Engine voice connector
```

Purpose:

```text
narration
character voice
dialogue
voiceover
user-recorded narration
voice manipulation
local/offline TTS
```

Do not require paid voice providers for MVP.

## D. Audio/video muxing and scene mixing

Add these rows or placeholders:

```text
Web Audio Scene Mixer
FFmpeg.wasm placeholder
Backend FFmpeg future optional
Load Local Engine muxing connector
```

Purpose:

```text
layer scene video
layer narration
layer ambience
layer SFX
layer music
preview scene with sound
mux separate audio into final video later
```

Do not block MVP on muxing.

---

# 15. Free/open-source/local-first provider priority order

Use this as the provider priority order for Load AI Chat MVP.

```text
1. Existing Load AI Image Generator
2. Existing Load Main provider/API key settings
3. Local SD / A1111-compatible route
4. Pollinations Flux
5. Pollinations classic
6. Pollinations Turbo
7. AI Horde anonymous
8. AI Horde SDXL anonymous
9. Hugging Face open-source routes where free/practical
10. Cloudflare free-tier routes only if already working and optional
11. Together free-tier routes only if truly free and optional
12. ComfyUI connector
13. ComfyUI AnimateDiff workflow
14. ComfyUI video workflow
15. Stable Diffusion local workflows
16. Prompt-only image provider
17. Prompt-only motion provider
18. Prompt-only sound design provider
19. Browser TTS
20. Piper
21. Kokoro TTS future local connector
22. User recording
23. Load voice manipulator
24. User-imported SFX library
25. Local/public-domain SFX library
26. Web Audio Scene Mixer
27. FFmpeg.wasm later
28. Load Local Engine future
```

---

# 16. Providers to remove from MVP requirements

Do not include these as MVP requirements:

```text
ElevenLabs
Replicate
Stability AI
other expensive paid-first providers
any provider requiring paid credits by default
any cloud provider that becomes a hard dependency
```

They may only be listed as:

```text
Future optional paid connectors
```

and must be:

```text
off by default
not required for MVP
not required for tests
not required for package export
not hard-coded
not exported
```

---

# 17. Built-in Load tools that must be audited and reused

Audit and reuse these before adding new modules:

```text
Load Built-in AI Image Generator
Load provider/API key settings
Load video player/editor
Load audio import/edit tools
Load recorder
Load browser TTS
Load Piper integration
Load voice manipulator
Load package validator
Load rights validator
Load safety scanner
Load export receipts/security reports
```

Do not rebuild existing tools from scratch.

Extend them into Load AI Chat Studio and LoadStudio.

---

# 18. Required UI additions

In AI Chat Studio, include or plan:

```text
Provider selector
Output type selector
Style selector
Reference image upload
Sound toggle
Sound prompt field
Music prompt field
SFX prompt field
Voice/narration option
Attach to Scene button
Save to Project button
Regenerate button
Extend animation button
Replace audio button
Add more SFX button
```

---

# 19. Required UI cards

## Image result card

Must include:

- title: Image Created
- sublabel: Text to Image or Image to Image
- preview image
- Save
- Export/share
- Feedback
- Attach to Project
- Attach to Scene
- Refine

## Animation pending card

Must include:

- title: Almost Ready or Animation in Progress
- sublabel: Video Animation
- source thumbnail
- progress indicator or status message

## Video result card

Must include:

- title: Video Created
- sublabel: Video Animation
- playable video or preview thumbnail
- Save
- Export/share
- Feedback
- Extend
- Attach to Project
- Attach to Scene

## Audio result card

Must include:

- title: Audio Created
- sublabel: SFX / Ambience / Music / Voice
- playable audio
- Attach to Scene
- Replace
- Layer
- Export

---

# 20. Required package folders and scene fields

Generated media must be saved into:

```text
assets/images/
assets/video/ or assets/media/
assets/audio/
assets/music/
assets/sfx/
assets/subtitles/
```

If `assets/video/` is added, update the validator to recognize it as optional or required for AI video packages.

Scene object should support:

```json
{
  "sceneId": "scene_ark_001",
  "image": "assets/images/ark_scene_001.png",
  "video": "assets/video/ark_scene_001_animation.mp4",
  "audioPrompt": "noisy crowd, mocking laughter, wood hammering, distant animals",
  "sfxPrompt": "crowd jeering, laughter, hammering wood, animal sounds",
  "musicPrompt": "tense ancient cinematic underscore",
  "ambiencePrompt": "outdoor ancient construction site, crowd noise, wind, distant animals",
  "audio": "assets/audio/ark_scene_001_mix.mp3",
  "music": "assets/music/ark_scene_001_underscore.mp3",
  "sfx": [
    "assets/sfx/crowd_mocking_laughter.mp3",
    "assets/sfx/wood_hammering.mp3"
  ],
  "audioStatus": "separate_audio_generated",
  "audioProvider": "provider-name-or-local-engine",
  "audioEmbedded": false,
  "audioMuxed": false,
  "audioRightsStatus": "needs-review"
}
```

---

# 21. Required project file updates

Write image, animation, audio, and provider metadata into:

```text
scenes.json
generation-report.json
asset-declarations.json
rights.json
continuity-report.json
prompt-log.json
chat-history.json
model-routing.json
```

Do not store generated assets only in chat history.

They must become structured project assets.

---

# 22. Output proof rules

These are mandatory:

```text
Do not claim image generation success unless a real file/blob/URL exists.
Do not claim image animation success unless a real playable video file/blob/URL exists.
Do not claim video success unless a real playable video file/blob/URL exists.
Do not claim sound generation success unless a real playable audio file/blob/URL exists.
Do not claim voice/narration success unless a real playable audio file/blob/URL exists.
Do not claim provider READY unless a real test succeeds.
Do not claim muxed video success unless a real muxed video file/blob/URL exists.
```

If only a prompt exists, say:

```text
Prompt saved
```

not:

```text
Generated
```

---

# 23. Acceptance criteria

The provider and workflow extension is not complete unless:

```text
1. Existing 17 image providers are audited.
2. Existing Load AI Image function is audited.
3. Built-in image generator is reused or honestly marked unavailable.
4. Existing Load Main provider/API key settings are reused.
5. No duplicate key settings are created.
6. Provider registry exists.
7. Provider capability detection includes image, img2img, animation, video, audio, SFX, ambience, music, voice, narration.
8. Provider test connection exists.
9. Prompt-only fallback exists for image, motion, sound, SFX, music, and voice.
10. Text-to-image provider slot exists.
11. Image-to-image provider slot exists.
12. Image animation provider slot exists.
13. Text-to-SFX provider slot exists.
14. Ambience provider slot exists.
15. Voice/narration provider slot exists.
16. Music cue provider slot exists.
17. ComfyUI connector placeholder exists.
18. AnimateDiff/ComfyUI video workflow placeholder exists.
19. Local/public-domain SFX library support exists or is planned clearly.
20. User-imported SFX library support exists.
21. Browser TTS and Piper remain available.
22. Kokoro TTS is listed as future local connector.
23. FFmpeg.wasm muxing is listed as later.
24. Load Local Engine is listed as future.
25. Optional paid providers are not required for MVP.
26. ElevenLabs, Replicate, and Stability AI are not MVP requirements.
27. No API key appears in exported ZIPs or reports.
28. Generated media is not marked successful unless proof exists.
29. Audio is not marked successful unless playable audio exists.
30. Video with audio is not claimed unless audio exists.
31. Scene attachment works or is honestly marked NOT DONE.
32. Package export includes generated assets or is honestly marked NOT DONE.
33. Validator accepts the updated package structure or is honestly marked NOT DONE.
34. Rights metadata is written.
35. Safety metadata is written.
```

---

# 24. Final Claude instruction

Claude, use this addendum to update the existing Load AI Cinema System plan.

Do not replace the prior ZIP.
Do not remove or weaken the existing:

- X-AI-CORE
- X-AI-CHAT-STUDIO
- X-STUDIO-AI
- X-VIDEO-AI
- X-AI-AUDIO

Do not replace the current 17 providers.
Audit and extend them.

Do not duplicate Load Main’s API/provider key settings.
Do not hard-code or export keys.
Do not fake output success.
Do not require expensive paid providers for MVP.

Add or extend support for:

```text
image generation
image-to-image
multi-style image generation
image animation
performance-style animation
real sound generation or attachment
realistic SFX
ambience
music cues
voice
narration
user-imported SFX
local/public-domain SFX library
ComfyUI
Stable Diffusion local workflows
A1111/local SD
Pollinations
AI Horde
Hugging Face open-source/free routes where practical
Browser TTS
Piper
Kokoro TTS future
FFmpeg.wasm later
Load Local Engine future
```

The goal is to make Load AI Chat Studio capable of real movie/content creation with the broadest practical free/open-source/local-first provider stack possible, while keeping output truthful, package-ready, and scene-aware.

