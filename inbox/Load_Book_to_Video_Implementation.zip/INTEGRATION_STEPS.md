# Step-by-Step Integration Guide

Step 1:
Copy the book-video folder into your existing load folder.

Step 2:
In load/index.html, add this CSS link before the closing head tag:

<link rel="stylesheet" href="./book-video/book-to-video.css">

Step 3:
Add these scripts before the closing body tag, after your main load.js:

<script src="./book-video/book-text-extractor.js"></script>
<script src="./book-video/scene-card-engine.js"></script>
<script src="./book-video/character-bible.js"></script>
<script src="./book-video/ai-provider-router.js"></script>
<script src="./book-video/timeline-bridge.js"></script>
<script src="./book-video/book-to-video-engine.js"></script>
<script src="./book-video/book-to-video-ui.js"></script>

Step 4:
Add a button anywhere in Load:

<button id="open-book-to-video">Book to Video</button>

Step 5:
Attach it:

document.getElementById("open-book-to-video").addEventListener("click", function () {
  window.LoadBookToVideo.open();
});

Step 6:
Confirm these objects exist in browser console:

window.LoadBookToVideo
window.BookTextExtractor
window.SceneCardEngine
window.CharacterBibleEngine
window.LoadTimelineBridge

Step 7:
Test with a TXT file first.

Step 8:
Then test with HTML/PWA book pages.

Step 9:
Then test PDF.

Step 10:
Then test EPUB.

Acceptance test:
A book file should become editable Scene Cards.
Each Scene Card should include characters, location, narration, visual prompt, captions, and a Send to Timeline button.
