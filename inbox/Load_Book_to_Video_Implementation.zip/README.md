# Load Book-to-Video Engine Implementation

Purpose:
Add a Book-to-Video engine to Load without replacing the existing sound system or video/media editor.

Core workflow:
1. Import book source
2. Extract text
3. Split text into chapters and scenes
4. Create editable Scene Cards
5. Build Character Bible
6. Generate prompts, narration, captions, and media tasks
7. Send approved scenes into the existing Load Media Editor timeline

Important:
This package is modular. Add these files to the Load folder and connect them to the existing Load UI.

Suggested file placement:
load/
  book-video/
    book-to-video.css
    book-to-video-engine.js
    book-to-video-ui.js
    book-text-extractor.js
    character-bible.js
    scene-card-engine.js
    ai-provider-router.js
    timeline-bridge.js
    schemas/

Integration:
1. Copy the book-video folder into load/
2. Add the CSS link to load/index.html
3. Add script tags after load.js or inside your module loader
4. Add a button in Load called "Book to Video"
5. On click, call:

window.LoadBookToVideo.open();

No existing sound or video system should be removed.
