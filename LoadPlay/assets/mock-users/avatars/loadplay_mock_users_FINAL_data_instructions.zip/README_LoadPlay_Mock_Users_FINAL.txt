LOADPLAY MOCK USERS FINAL REBUILD

This package contains the corrected mixed-style mock users for LoadPlay Test Mode.

CONTENTS
/assets/mock-users/avatars/
  user_001.jpg through user_500.jpg

/data/
  demo-users.json
  demo-activity.json
  source-log.json

/docs/
  preview_001_100.jpg
  preview_101_200.jpg
  preview_201_300.jpg
  preview_301_400.jpg
  preview_401_500.jpg

PROFILE MIX
001-100: realistic people, professional, casual, older adults, students, varied settings
101-200: creators and influencers, beauty, fashion, podcasting, music, fitness, photography
201-300: activity profiles, cycling, cooking, gardening, coding, nursing, art, study, running, surfing
301-400: non-human profile images, cars, pets, fashion items, cameras, coffee, flowers, books, travel scenery
401-500: mixed realistic platform profiles

INSTALL
1. Copy /assets/mock-users/avatars/ into your LoadPlay project.
2. Copy /data/demo-users.json and /data/demo-activity.json into your LoadPlay /data folder.
3. In Admin > Test Mode, load demo-users.json only when Test Mode is active.
4. Never merge demo users with real users.
5. Use isDemo: true and testModeOnly: true as safeguards.
6. Avatar paths are already written as:
   /assets/mock-users/avatars/user_001.jpg

VERIFICATION
This package was built from the approved mixed-profile visual direction. It includes individual avatar image files, not only contact sheets.
