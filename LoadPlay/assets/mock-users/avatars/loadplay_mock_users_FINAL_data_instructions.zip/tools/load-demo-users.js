async function loadDemoUsers() {
  const testMode = localStorage.getItem('LOADPLAY_TEST_MODE') === 'true';
  if (!testMode) return [];

  const response = await fetch('/data/demo-users.json');
  const users = await response.json();

  const safeUsers = users.filter(user => user.isDemo === true && user.testModeOnly === true);
  localStorage.setItem('LOADPLAY_DEMO_USERS', JSON.stringify(safeUsers));

  return safeUsers;
}

function enableTestMode() {
  localStorage.setItem('LOADPLAY_TEST_MODE', 'true');
  document.body.classList.add('test-mode-active');
}

function disableTestMode() {
  localStorage.removeItem('LOADPLAY_TEST_MODE');
  localStorage.removeItem('LOADPLAY_DEMO_USERS');
  document.body.classList.remove('test-mode-active');
}

window.LoadPlayDemoUsers = { loadDemoUsers, enableTestMode, disableTestMode };
