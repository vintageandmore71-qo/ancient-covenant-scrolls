LOADPLAY MOCK USERS NAME FIX

This package updates the mock-user data so every displayName, username, and handle is unique.

WHAT CHANGED
- All 500 display names are unique.
- All 500 usernames are unique.
- All 500 handles are unique.
- Non-human profile users 301-400 now use professional object, pet, car, travel, fashion, coffee, camera, book, home, and lifestyle profile names.
- Avatar paths remain unchanged.

USE THIS FILE TO REPLACE THE OLDER DATA FILE:
/data/demo-users.json

KEEP THE SAME AVATAR FOLDERS:
/assets/mock-users/avatars/user_001.jpg through user_500.jpg

VERIFICATION FILE:
/data/name-uniqueness-verification.json

IMPORTANT
This is for LoadPlay Test Mode only. Demo users must only load when Test Mode is active and must not be mixed with real users.
